package com.rain.client.util;

import java.util.ArrayList;
import java.util.List;

/** Lifetime statistics plus a bounded window of the most recent values (for graphs). */
public final class Stats {
    private final int cap;
    private final List<Double> recent = new ArrayList<>();
    public int count;
    public double total;
    public double min = Double.MAX_VALUE;
    public double max = -Double.MAX_VALUE;
    public double last;

    public Stats(int cap) {
        this.cap = cap;
    }

    public void add(double v) {
        recent.add(v);
        if (recent.size() > cap) recent.remove(0);
        count++;
        total += v;
        min = Math.min(min, v);
        max = Math.max(max, v);
        last = v;
    }

    public double avg() {
        return count == 0 ? 0 : total / count;
    }

    public List<Double> recent() {
        return recent;
    }

    public void clear() {
        recent.clear();
        count = 0;
        total = 0;
        min = Double.MAX_VALUE;
        max = -Double.MAX_VALUE;
        last = 0;
    }
}
