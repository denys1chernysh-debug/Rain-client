package com.rain.client.module.combat;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Indicator only: shows when an attack would be triggered. It never attacks. */
public final class Triggerbot extends Module {
    private final Setting.Num delay = add(new Setting.Num("Delay", "How long a target must stay under the crosshair before the indicator turns READY.", 80, 0, 500, 10, " ms"));
    private final Setting.Num range = add(new Setting.Num("Range", "Maximum distance of the target.", 3, 1, 6, 0.1, " m"));
    private final Setting.Multi types = add(new Setting.Multi("Target Types", "Which kinds of entities are eligible.", Targets.TYPES, new boolean[]{false, true, true, true, false}));
    private final Setting.Bool visibleOnly = add(new Setting.Bool("Require Line of Sight", "Ignore targets that are behind blocks.", true));
    private final Setting.Bool indicator = add(new Setting.Bool("Visual Indicator", "Draw the timing indicator under the crosshair.", true));

    private Entity held;
    private long heldSince;
    private boolean ready, wasReady;
    private int wouldTrigger;
    private long msHeld;

    public Triggerbot() {
        super("Triggerbot", Category.COMBAT,
                "Shows when a target under the crosshair is in range and an attack would be triggered.",
                "Indicator only: it does not attack for you. It uses the entity under your crosshair as the client sees it.");
    }

    @Override
    public void onEnable() {
        held = null;
        ready = wasReady = false;
        wouldTrigger = 0;
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        Entity t = mc.crosshairPickEntity;
        boolean ok = t != null && Targets.eligible(p, t, true) && Targets.typeAllowed(types, t) && p.distanceTo(t) <= range.get();
        if (ok && visibleOnly.get()) {
            Vec3 eye = p.getEyePosition();
            ok = Targets.visible(mc, eye, t.getBoundingBox().getCenter());
        }
        long now = System.currentTimeMillis();
        if (ok) {
            if (t != held) {
                held = t;
                heldSince = now;
            }
            msHeld = now - heldSince;
            ready = msHeld >= delay.get();
            if (ready && !wasReady) wouldTrigger++;
            wasReady = ready;
        } else {
            held = null;
            ready = false;
            wasReady = false;
            msHeld = 0;
        }
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (!indicator.get() || o.mc.screen != null) return;
        int cx = o.w / 2, cy = o.h / 2 + 12;
        if (held == null) return;
        if (ready) {
            o.centered("READY", cx, cy, 0xFF5CC46B);
        } else {
            long left = Math.max(0, (long) delay.get() - msHeld);
            o.centered("wait " + left + " ms", cx, cy, 0xFFE6C84A);
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add(held == null ? "No eligible target" : "Target: " + Targets.describe(held));
        l.add("Would trigger: " + wouldTrigger + " times");
        l.add("Indicator only (no attacks sent)");
        return l;
    }
}
