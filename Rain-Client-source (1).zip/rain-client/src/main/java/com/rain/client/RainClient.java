package com.rain.client;

import com.rain.client.gui.RainScreen;
import com.rain.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RainClient implements ClientModInitializer {
    public static final String VERSION = "1.0.0";
    public static final Logger LOG = LoggerFactory.getLogger("Rain");

    private boolean shiftWas;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Config.load();

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("rain", "overlay"), (graphics, deltaTracker) -> Hud.render(graphics, deltaTracker));
        Runtime.getRuntime().addShutdownHook(new Thread(Config::save, "rain-config-save"));
        LOG.info("Rain Client {} loaded ({} modules). Press RIGHT SHIFT in a world to open the GUI.", VERSION, ModuleManager.ALL.size());
    }

    private void tick(Minecraft mc) {
        try {
            long win = mc.getWindow().handle();
            boolean shift = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (shift && !shiftWas && mc.screen == null && mc.level != null) {
                mc.setScreenAndShow(new RainScreen());
            }
            shiftWas = shift;
        } catch (Throwable t) {
            LOG.error("Rain GUI hotkey failed", t);
        }
        ModuleManager.tick(mc);
        Config.tick();
    }
}
