package com.rain.client.module.combat;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Stats;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * CPS trainer and tester. It measures YOUR clicks and shows a metronome cue to practise against.
 * It does not click for you.
 */
public final class AutoClicker extends Module {
    private final Setting.Num target = add(new Setting.Num("Target CPS", "Clicks per second the practice metronome aims for.", 10, 1, 20, 0.5, ""));
    private final Setting.Num min = add(new Setting.Num("Minimum CPS", "The metronome never goes slower than this.", 6, 1, 20, 0.5, ""));
    private final Setting.Num max = add(new Setting.Num("Maximum CPS", "The metronome never goes faster than this.", 14, 1, 30, 0.5, ""));
    private final Setting.Num random = add(new Setting.Num("Randomization", "Random variation of the metronome interval (practice with uneven rhythms).", 20, 0, 50, 1, "%"));
    private final Setting.Bool cpsDisplay = add(new Setting.Bool("CPS Display", "Show live CPS and statistics in the HUD panel.", true));
    private final Setting.Bool metronome = add(new Setting.Bool("Metronome Cue", "Flash a CLICK cue on screen at the practice interval.", true));

    private final ArrayDeque<Long> clicks = new ArrayDeque<>();
    private final Stats intervals = new Stats(60);
    private final Stats deviation = new Stats(60);
    private final Random rng = new Random();
    private boolean prevDown;
    private long lastClick, nextCue, lastCue;
    private int peak, total;

    public AutoClicker() {
        super("Auto Clicker", Category.COMBAT,
                "CPS tester and click trainer with a randomized practice metronome.",
                "It measures and trains your own clicking only; it does not generate clicks. No anti-cheat evasion or human-impersonation features are included.");
    }

    @Override
    public void onEnable() {
        clicks.clear();
        intervals.clear();
        deviation.clear();
        prevDown = false;
        lastClick = 0;
        peak = total = 0;
        long now = System.currentTimeMillis();
        lastCue = now;
        nextCue = now + 500;
    }

    private void scheduleCue(long now) {
        double lo = Math.min(min.get(), max.get()), hi = Math.max(min.get(), max.get());
        double cps = target.get() * (1.0 + (rng.nextDouble() * 2 - 1) * random.get() / 100.0);
        cps = Math.max(lo, Math.min(hi, cps));
        lastCue = nextCue;
        nextCue = now + (long) (1000.0 / cps);
    }

    @Override
    public void renderOverlay(Overlay o) {
        long now = System.currentTimeMillis();

        if (o.mc.screen == null) {
            boolean down = GLFW.glfwGetMouseButton(o.mc.getWindow().handle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
            if (down && !prevDown) registerClick(now);
            prevDown = down;
        } else {
            prevDown = false;
        }

        if (metronome.get()) {
            if (now >= nextCue) scheduleCue(now);
            if (now - lastCue < 110) o.centered("CLICK", o.w / 2, o.h / 2 + 24, 0xFFE8EAED);
        }
    }

    private void registerClick(long now) {
        clicks.addLast(now);
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.removeFirst();
        peak = Math.max(peak, clicks.size());
        total++;
        if (lastClick > 0) intervals.add(now - lastClick);
        lastClick = now;
        if (metronome.get()) {
            deviation.add(Math.min(Math.abs(now - lastCue), Math.abs(now - nextCue)));
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        if (!cpsDisplay.get()) return l;
        long now = System.currentTimeMillis();
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.removeFirst();
        l.add("CPS: " + clicks.size() + "   peak: " + peak);
        if (intervals.count > 0) {
            l.add("Interval avg: " + Util.f1(intervals.avg()) + " ms (min " + (int) intervals.min + ", max " + (int) intervals.max + ")");
        }
        if (metronome.get() && deviation.count > 0) {
            l.add("Cue error avg: " + Util.f1(deviation.avg()) + " ms");
        }
        l.add("Clicks counted: " + total);
        return l;
    }
}
