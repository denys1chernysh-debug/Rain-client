package com.rain.client.module.crystal;

import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Weapon selection assistant: scans the hotbar and recommends what to hold. It never switches for you. */
public final class BreachSwap extends Module {
    private final Setting.Bool weaponDetection = add(new Setting.Bool("Weapon Detection", "List the weapons found in your hotbar.", true));
    private final Setting.Bool enchantDisplay = add(new Setting.Bool("Enchantment Display", "Show enchantments next to detected weapons.", true));
    private final Setting.Bool notifications = add(new Setting.Bool("Notifications", "Chat message when the recommendation changes.", false));

    private final List<String> found = new ArrayList<>();
    private String recommendation = "";
    private String reason = "";
    private String lastRecommendation = "";
    private int lastSlot = -1, switches;
    private long lastSwitchMs;

    public BreachSwap() {
        super("Breach Swap", Category.CRYSTAL_MACE,
                "Detects hotbar weapons and mace enchantments and recommends the best weapon for the situation.",
                "Recommendation only: it does not switch slots for you. It reads enchantments the client has been sent; the armor of a target is read from the entity under your crosshair.");
    }

    @Override
    public void onEnable() {
        switches = 0;
        lastSlot = -1;
        lastRecommendation = "";
    }

    private static boolean isWeapon(String id) {
        return id.endsWith("_sword") || id.endsWith("_axe") || id.equals("mace") || id.equals("trident") || id.endsWith("_spear");
    }

    private static int rank(String id) {
        if (id.startsWith("netherite")) return 6;
        if (id.startsWith("diamond")) return 5;
        if (id.startsWith("iron")) return 4;
        if (id.startsWith("copper")) return 3;
        if (id.startsWith("stone")) return 2;
        return 1;
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        found.clear();

        int slotNow = p.getInventory().getSelectedSlot();
        if (lastSlot >= 0 && slotNow != lastSlot) {
            switches++;
            lastSwitchMs = System.currentTimeMillis();
        }
        lastSlot = slotNow;

        int bestSword = -1, bestAxe = -1, mace = -1, breachMace = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getItem(i);
            String id = Util.id(s);
            if (!isWeapon(id)) continue;
            String ench = Util.enchants(s).toString();
            found.add("Slot " + (i + 1) + ": " + Util.pretty(id) + (enchantDisplay.get() && !ench.equals("[]") ? " " + ench : ""));
            if (id.endsWith("_sword") && (bestSword < 0 || rank(id) > rank(Util.id(p.getInventory().getItem(bestSword))))) bestSword = i;
            if (id.endsWith("_axe") && (bestAxe < 0 || rank(id) > rank(Util.id(p.getInventory().getItem(bestAxe))))) bestAxe = i;
            if (id.equals("mace")) {
                if (mace < 0) mace = i;
                if (Util.hasEnchant(s, "Breach") && breachMace < 0) breachMace = i;
            }
        }

        int armor = mc.crosshairPickEntity instanceof LivingEntity le ? le.getArmorValue() : 0;
        boolean falling = !p.onGround() && p.getDeltaMovement().y < -0.3;

        int pick = -1;
        if (falling && breachMace >= 0 && armor >= 10) { pick = breachMace; reason = "falling, target armor " + armor + ": Breach cuts armor"; }
        else if (falling && mace >= 0) { pick = mace; reason = "falling: smash attack"; }
        else if (bestSword >= 0) { pick = bestSword; reason = "best sword for normal combat"; }
        else if (bestAxe >= 0) { pick = bestAxe; reason = "axe (no sword in hotbar)"; }
        else if (mace >= 0) { pick = mace; reason = "only weapon found"; }

        if (pick < 0) {
            recommendation = "";
            reason = "no weapon in hotbar";
        } else {
            recommendation = "Slot " + (pick + 1) + " " + Util.pretty(Util.id(p.getInventory().getItem(pick)));
        }
        if (notifications.get() && !recommendation.equals(lastRecommendation) && !recommendation.isEmpty()) {
            Util.chat("Recommended: " + recommendation + " (" + reason + ")");
        }
        lastRecommendation = recommendation;
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        if (weaponDetection.get()) {
            if (found.isEmpty()) l.add("No weapons in hotbar");
            l.addAll(found);
        }
        l.add(recommendation.isEmpty() ? "Recommend: -" : "Recommend: " + recommendation);
        l.add("Why: " + reason);
        l.add("Switches: " + switches + (lastSwitchMs > 0 ? "  last " + (System.currentTimeMillis() - lastSwitchMs) / 1000 + " s ago" : ""));
        return l;
    }
}
