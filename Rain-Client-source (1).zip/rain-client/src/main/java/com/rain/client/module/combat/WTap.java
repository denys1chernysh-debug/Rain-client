package com.rain.client.module.combat;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Stats;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Sprint-reset timing trainer. An "attack" is detected as a left click while an entity is under the
 * crosshair (the client has no separate attack event without game hooks). A successful W-tap is a
 * sprint stop followed by sprint resuming inside the timing window.
 */
public final class WTap extends Module {
    private final Setting.Num window = add(new Setting.Num("Timing Window", "Maximum time after the attack in which the sprint must stop and resume.", 400, 100, 1000, 25, " ms"));
    private final Setting.Bool feedback = add(new Setting.Bool("Visual Feedback", "Flash the result of each attempt under the crosshair.", true));
    private final Setting.Bool statistics = add(new Setting.Bool("Statistics", "Show attempts, successes and timings in the HUD panel.", true));

    private final Stats resetGap = new Stats(30);
    private boolean prevClick, wasSprinting;
    private long attackAt, stoppedAt, resultAt;
    private boolean armed, stopped;
    private int attempts, successes, streak, best;
    private String result = "";

    public WTap() {
        super("W-Tap", Category.COMBAT,
                "Sprint-reset timing trainer: tracks your attacks and whether you reset sprint in time.",
                "Attacks are inferred from left clicks while targeting an entity, so server-side misses/cooldowns are not known. Shows timing only; no input is sent.");
    }

    @Override
    public void onEnable() {
        armed = stopped = false;
        attempts = successes = streak = best = 0;
        resetGap.clear();
        result = "";
    }

    @Override
    public void renderOverlay(Overlay o) {
        Minecraft mc = o.mc;
        LocalPlayer p = mc.player;
        long now = System.currentTimeMillis();

        boolean click = mc.screen == null && GLFW.glfwGetMouseButton(mc.getWindow().handle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean sprint = p.isSprinting();

        if (click && !prevClick && mc.crosshairPickEntity != null) {
            if (armed) finish(now, false, "no reset");
            armed = true;
            stopped = false;
            attackAt = now;
            attempts++;
        }
        prevClick = click;

        if (armed) {
            if (now - attackAt > window.get()) {
                finish(now, false, stopped ? "too slow" : "no reset");
            } else if (!sprint && wasSprinting) {
                stopped = true;
                stoppedAt = now;
            } else if (sprint && stopped) {
                resetGap.add(now - attackAt);
                finish(now, true, "reset in " + (now - attackAt) + " ms");
            }
        }
        wasSprinting = sprint;

        if (feedback.get() && now - resultAt < 900 && !result.isEmpty()) {
            o.centered(result, o.w / 2, o.h / 2 + 36, result.startsWith("OK") ? 0xFF5CC46B : 0xFFE5534B);
        } else if (feedback.get() && armed) {
            long left = Math.max(0, (long) window.get() - (now - attackAt));
            o.centered(stopped ? "release done - resume sprint" : "tap back now (" + left + " ms)", o.w / 2, o.h / 2 + 36, 0xFFE6C84A);
        }
    }

    private void finish(long now, boolean ok, String why) {
        armed = false;
        stopped = false;
        resultAt = now;
        if (ok) {
            successes++;
            streak++;
            best = Math.max(best, streak);
            result = "OK: " + why;
        } else {
            streak = 0;
            result = "MISS: " + why;
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("Sprint: " + (Minecraft.getInstance().player != null && Minecraft.getInstance().player.isSprinting() ? "on" : "off"));
        if (statistics.get()) {
            l.add("Attacks: " + attempts + "  Resets: " + successes);
            l.add("Streak: " + streak + "  Best: " + best);
            if (resetGap.count > 0) l.add("Reset time avg: " + Util.f1(resetGap.avg()) + " ms");
        }
        return l;
    }
}
