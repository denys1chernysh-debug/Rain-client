package com.rain.client.module.crystal;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Respawn-anchor practice helper: shows charge level and the interaction sequence. Display only. */
public final class AnchorMacro extends Module {
    private final Setting.Bool chargeIndicators = add(new Setting.Bool("Charge Indicators", "Draw charge pips above the anchor you are looking at.", true));
    private final Setting.Bool sequence = add(new Setting.Bool("Interaction Sequence", "Show the correct next step in the HUD panel.", true));
    private final Setting.Bool timing = add(new Setting.Bool("Timing Display", "Show time between charges and time to full charge.", true));

    private BlockPos anchor;
    private int charges = -1;
    private long lastChangeMs, firstChargeMs, fullMs;
    private long sinceLast;
    private boolean overworldLike;

    public AnchorMacro() {
        super("Anchor Macro", Category.CRYSTAL_MACE,
                "Recognizes respawn anchors, tracks glowstone charges and shows the correct interaction sequence.",
                "Practice helper only: it shows information and timing; it does not place anchors, use glowstone or interact for you.");
    }

    @Override
    public void onEnable() {
        anchor = null;
        charges = -1;
        firstChargeMs = fullMs = lastChangeMs = 0;
    }

    @Override
    public void tick(Minecraft mc) {
        anchor = null;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = hit.getBlockPos();
        BlockState st = mc.level.getBlockState(pos);
        if (!Util.id(st.getBlock()).equals("respawn_anchor")) return;
        anchor = pos;
        int c = st.getValue(BlockStateProperties.RESPAWN_ANCHOR_CHARGES);
        long now = System.currentTimeMillis();
        if (c != charges) {
            if (c == 1 && charges == 0) firstChargeMs = now;
            if (c == 4) fullMs = firstChargeMs == 0 ? 0 : now - firstChargeMs;
            lastChangeMs = now;
            charges = c;
        }
        sinceLast = now - lastChangeMs;
        String dim = mc.level.dimension().toString();
        overworldLike = !dim.contains("the_nether");
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (anchor == null || !chargeIndicators.get()) return;
        Vec3 top = Vec3.atCenterOf(anchor).add(0, 0.9, 0);
        double[] p = o.project(top);
        if (p == null) return;
        int x = (int) p[0] - 20, y = (int) p[1];
        for (int i = 0; i < 4; i++) {
            int c = i < charges ? 0xFFE6C84A : 0x80808890;
            o.rect(x + i * 11, y, x + i * 11 + 9, y + 5, c);
        }
        o.centered(charges + "/4", (int) p[0], y - 11, 0xFFE8EAED);
        o.box(new AABB(anchor), 0xFFC8CDD4, 1);
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        if (anchor == null) {
            l.add("Look at a respawn anchor");
            return l;
        }
        l.add("Charges: " + charges + " / 4");
        if (sequence.get()) {
            if (charges == 0) l.add("Next: right-click with glowstone");
            else if (charges < 4) l.add("Next: add glowstone (up to 4)");
            else l.add("Fully charged (glowstone no longer works)");
            l.add(overworldLike ? "Here: using a charged anchor makes it explode" : "Nether: using a charged anchor sets spawn");
        }
        if (timing.get()) {
            l.add("Since last change: " + sinceLast + " ms");
            if (fullMs > 0) l.add("0 to full: " + fullMs + " ms");
        }
        return l;
    }
}
