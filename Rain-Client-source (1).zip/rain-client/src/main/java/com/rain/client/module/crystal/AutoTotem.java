package com.rain.client.module.crystal;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/** Offhand monitor. It reports and points at a refill; it does not move items for you. */
public final class AutoTotem extends Module {
    private final Setting.Bool refillNotifications = add(new Setting.Bool("Refill Notifications", "Chat message when the offhand totem is gone and another is available.", true));
    private final Setting.Bool inventoryStatus = add(new Setting.Bool("Inventory Status", "Show how many totems are in your inventory and where.", true));
    private final Setting.Bool offhandHud = add(new Setting.Bool("Offhand HUD", "Draw an offhand status line near the hotbar.", true));

    private boolean hadTotem;
    private boolean init;
    private int totems, firstSlot = -1;
    private int pops;
    private long lastNotify;

    public AutoTotem() {
        super("Auto Totem", Category.CRYSTAL_MACE,
                "Monitors your offhand for a Totem of Undying and tells you when and where to refill.",
                "This build only monitors and notifies. It does not move items: the container-click API for 26.2 could not be verified here, so automatic swapping was left out rather than shipped unverified.");
    }

    @Override
    public void onEnable() {
        init = false;
        pops = 0;
    }

    private static boolean isTotem(ItemStack s) {
        return Util.id(s).equals("totem_of_undying");
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        boolean has = isTotem(p.getOffhandItem());
        totems = 0;
        firstSlot = -1;
        for (int i = 0; i < p.getInventory().getContainerSize(); i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (isTotem(s)) {
                totems += s.getCount();
                if (firstSlot < 0) firstSlot = i;
            }
        }
        if (init && hadTotem && !has) {
            pops++;
            long now = System.currentTimeMillis();
            if (refillNotifications.get() && now - lastNotify > 1000) {
                lastNotify = now;
                Util.chat(totems > 0 ? "Offhand totem gone - refill from " + slotName(firstSlot) : "Offhand totem gone - no spare totems!");
            }
        }
        hadTotem = has;
        init = true;
    }

    private static String slotName(int slot) {
        if (slot < 0) return "none";
        if (slot < 9) return "hotbar " + (slot + 1);
        return "inventory slot " + (slot - 8);
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (!offhandHud.get()) return;
        String s = hadTotem ? "Offhand: totem ready" : (totems > 0 ? "Offhand EMPTY - spare in " + slotName(firstSlot) : "Offhand EMPTY - no totems");
        int color = hadTotem ? 0xFF5CC46B : 0xFFE5534B;
        o.centered(s, o.w / 2 - 110, o.h - 52, color);
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("Offhand: " + (hadTotem ? "totem" : "empty/other"));
        if (inventoryStatus.get()) {
            l.add("Totems in inventory: " + totems);
            if (firstSlot >= 0) l.add("Spare at: " + slotName(firstSlot));
        }
        l.add("Offhand totems used: " + pops);
        return l;
    }
}
