package com.rain.client.module;

import com.rain.client.module.base.ActivityTrackers;
import com.rain.client.module.base.AutoBaseHunt;
import com.rain.client.module.base.BaseFinder;
import com.rain.client.module.base.BlockEsp;
import com.rain.client.module.base.StorageEsp;
import com.rain.client.module.combat.AimAssist;
import com.rain.client.module.combat.AutoClicker;
import com.rain.client.module.combat.Hitboxes;
import com.rain.client.module.combat.SilentAim;
import com.rain.client.module.combat.Triggerbot;
import com.rain.client.module.combat.Velocity;
import com.rain.client.module.combat.WTap;
import com.rain.client.module.crystal.AnchorMacro;
import com.rain.client.module.crystal.AutoCrystal;
import com.rain.client.module.crystal.AutoMace;
import com.rain.client.module.crystal.AutoTotem;
import com.rain.client.module.crystal.BreachSwap;
import com.rain.client.module.crystal.CrystalOptimizer;
import com.rain.client.module.crystal.WindChargePearl;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    private static final Map<Module, Boolean> KEY_STATE = new HashMap<>();

    private ModuleManager() {}

    public static void init() {
        ALL.clear();
        // Combat & Sword PvP
        ALL.add(new AimAssist());
        ALL.add(new SilentAim());
        ALL.add(new Triggerbot());
        ALL.add(new AutoClicker());
        ALL.add(new WTap());
        ALL.add(new Velocity());
        ALL.add(new Hitboxes());
        // Crystal & Mace
        ALL.add(new AutoCrystal());
        ALL.add(new CrystalOptimizer());
        ALL.add(new AnchorMacro());
        ALL.add(new AutoTotem());
        ALL.add(new AutoMace());
        ALL.add(new BreachSwap());
        ALL.add(new WindChargePearl());
        // Base Hunting
        ALL.add(new BaseFinder());
        ALL.add(new AutoBaseHunt());
        ALL.add(new StorageEsp());
        ALL.add(new BlockEsp());
        ALL.add(new ActivityTrackers());
    }

    public static List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    /** Case-insensitive search over module names and descriptions across all categories. */
    public static List<Module> search(String query) {
        String q = query.toLowerCase(Locale.ROOT).trim();
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) {
            if (m.name.toLowerCase(Locale.ROOT).contains(q) || m.description.toLowerCase(Locale.ROOT).contains(q)) out.add(m);
        }
        return out;
    }

    public static void guard(Module m, String phase, Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            m.fail(phase, t);
        }
    }

    public static void tick(Minecraft mc) {
        long win = mc.getWindow().handle();
        for (Module m : ALL) {
            if (m.keybind < 0) continue;
            boolean down = GLFW.glfwGetKey(win, m.keybind) == GLFW.GLFW_PRESS;
            boolean was = KEY_STATE.getOrDefault(m, false);
            if (down && !was && mc.screen == null) {
                m.toggle();
                com.rain.client.Config.markDirty();
            }
            KEY_STATE.put(m, down);
        }
        if (mc.player == null || mc.level == null) return;
        for (Module m : ALL) {
            if (m.enabled) guard(m, "tick", () -> m.tick(mc));
        }
    }
}
