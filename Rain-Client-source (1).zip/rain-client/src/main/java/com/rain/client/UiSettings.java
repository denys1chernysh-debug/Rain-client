package com.rain.client;

/**
 * The three transparency controls. They are fully independent of each other:
 * <ul>
 *   <li>interfaceOpacity (10-100): overall opacity of everything the GUI draws, including text.</li>
 *   <li>buttonTransparency (0-100): transparency of cards, buttons, toggles and slider tracks.</li>
 *   <li>backgroundTransparency (0-100): transparency of the window and sidebar panels.</li>
 * </ul>
 */
public final class UiSettings {
    public static final int DEF_INTERFACE_OPACITY = 90;
    public static final int DEF_BUTTON_TRANSPARENCY = 70;
    public static final int DEF_BACKGROUND_TRANSPARENCY = 40;

    public static int interfaceOpacity = DEF_INTERFACE_OPACITY;
    public static int buttonTransparency = DEF_BUTTON_TRANSPARENCY;
    public static int backgroundTransparency = DEF_BACKGROUND_TRANSPARENCY;
    public static int category = 0;

    private UiSettings() {}

    public static void reset() {
        interfaceOpacity = DEF_INTERFACE_OPACITY;
        buttonTransparency = DEF_BUTTON_TRANSPARENCY;
        backgroundTransparency = DEF_BACKGROUND_TRANSPARENCY;
    }

    public static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
