package com.rain.client.module.combat;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.List;

public final class Hitboxes extends Module {
    private final Setting.Num thickness = add(new Setting.Num("Outline Thickness", "Outline width in pixels.", 1, 1, 4, 1, " px"));
    private final Setting.Num range = add(new Setting.Num("Range", "Maximum distance of entities that are outlined.", 24, 4, 64, 1, " m"));
    private final Setting.Color playerColor = add(new Setting.Color("Player Color", "Outline color for players.", 0));
    private final Setting.Color otherColor = add(new Setting.Color("Entity Color", "Outline color for other entities.", 2));
    private final Setting.Color selectedColor = add(new Setting.Color("Selected Color", "Outline color for the entity under your crosshair.", 5));
    private final Setting.Bool playerOnly = add(new Setting.Bool("Player-only Mode", "Only outline players.", false));
    private final Setting.Bool dimensions = add(new Setting.Bool("Show Dimensions", "Label players with their hitbox width x height.", true));
    private final Setting.Multi visibility = add(new Setting.Multi("Entity Visibility", "Which kinds of entities are outlined (ignored in player-only mode).", Targets.TYPES, new boolean[]{true, true, true, true, false}));

    private int drawn;

    public Hitboxes() {
        super("Hitboxes", Category.COMBAT,
                "Outlines entity hitboxes, shows player dimensions and highlights the entity you are aiming at.",
                "Boxes are drawn as screen-space outlines in first person (not as 3D lines). The hitbox is the client's copy; the server's can differ slightly due to latency.");
    }

    @Override
    public void renderOverlay(Overlay o) {
        drawn = 0;
        Entity selected = o.mc.crosshairPickEntity;
        for (Entity e : o.mc.level.entitiesForRendering()) {
            if (e == o.mc.player || e.isInvisible() && !(e instanceof Player)) continue;
            if (o.mc.player.distanceTo(e) > range.get()) continue;
            boolean isPlayer = e instanceof Player;
            if (playerOnly.get() && !isPlayer) continue;
            if (!playerOnly.get() && !visibility.has(Targets.category(e))) continue;

            int color = e == selected ? selectedColor.argb() : isPlayer ? playerColor.argb() : otherColor.argb();
            AABB b = e.getBoundingBox();
            if (o.box(b, color, thickness.getInt())) {
                drawn++;
                if (dimensions.get() && isPlayer) {
                    double[] p = o.project(b.minX, b.maxY, b.minZ);
                    if (p != null) o.text(Util.f2(b.getXsize()) + "x" + Util.f2(b.getYsize()), (int) p[0], (int) p[1] - 10, color);
                }
            }
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("Boxes drawn: " + drawn);
        return l;
    }
}
