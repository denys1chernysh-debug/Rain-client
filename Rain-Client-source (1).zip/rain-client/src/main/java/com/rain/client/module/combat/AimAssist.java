package com.rain.client.module.combat;

import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public final class AimAssist extends Module {
    private final Setting.Num range = add(new Setting.Num("Range", "Maximum target distance in blocks.", 6, 1, 12, 0.5, " m"));
    private final Setting.Num fov = add(new Setting.Num("FOV", "Full width of the cone around your crosshair in which targets are considered.", 90, 10, 360, 5, "°"));
    private final Setting.Num strength = add(new Setting.Num("Aim Strength", "How much of the remaining angle is closed each tick.", 35, 1, 100, 1, "%"));
    private final Setting.Num speed = add(new Setting.Num("Aim Speed", "Maximum camera movement per tick, in degrees.", 6, 1, 30, 0.5, "°"));
    private final Setting.Mode priority = add(new Setting.Mode("Target Priority", "How the target is chosen among eligible ones.", Targets.PRIORITIES, 1));
    private final Setting.Bool vertical = add(new Setting.Bool("Vertical Aiming", "Allow pitch (up/down) assistance.", true));
    private final Setting.Bool horizontal = add(new Setting.Bool("Horizontal Aiming", "Allow yaw (left/right) assistance.", true));
    private final Setting.Bool players = add(new Setting.Bool("Include Players", "Also treat other players as practice targets (e.g. a friend on your LAN world).", false));

    private Entity target;
    private String status = "";

    public AimAssist() {
        super("Aim Assist", Category.COMBAT,
                "Smoothly nudges your camera toward a practice target (dummies and mobs).",
                "Only active in singleplayer worlds (including worlds opened to LAN). It never runs on remote servers. "
                        + "Armor stands, mobs and (optionally) players are targets; nothing is attacked for you.");
    }

    @Override
    public void onDisable() {
        target = null;
    }

    @Override
    public void tick(Minecraft mc) {
        target = null;
        if (!Util.practiceWorld(mc)) {
            status = "Inactive: not a singleplayer world";
            return;
        }
        if (mc.screen != null) {
            status = "Paused (screen open)";
            return;
        }
        status = "Active";
        LocalPlayer p = mc.player;
        target = Targets.best(mc, range.get(), fov.get(), priority.idx(), players.get(), false);
        if (target == null) return;

        Vec3 eye = p.getEyePosition();
        Vec3 aim = target.getBoundingBox().getCenter();
        float dyaw = Mth.wrapDegrees(Targets.yawTo(eye, aim) - p.getYRot());
        float dpitch = Targets.pitchTo(eye, aim) - p.getXRot();
        double k = strength.get() / 100.0;
        double max = speed.get();

        if (horizontal.get()) p.setYRot(p.getYRot() + (float) Mth.clamp(dyaw * k, -max, max));
        if (vertical.get()) p.setXRot(Mth.clamp(p.getXRot() + (float) Mth.clamp(dpitch * k, -max, max), -90f, 90f));
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add(status);
        if (target != null) {
            l.add("Target: " + Targets.describe(target));
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) l.add("Distance: " + Util.f1(mc.player.distanceTo(target)) + " m");
        }
        return l;
    }
}
