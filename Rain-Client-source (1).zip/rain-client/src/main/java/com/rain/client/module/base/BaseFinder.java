package com.rain.client.module.base;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Scores loaded chunks for signs of player building, using only block data the client already received.
 * Every result lists the reasons behind its score.
 */
public final class BaseFinder extends Module {
    /** One scored chunk. */
    public static final class Detection {
        public final int cx, cz, percent;
        public final BlockPos center;
        public final List<String> reasons;

        Detection(int cx, int cz, int percent, BlockPos center, List<String> reasons) {
            this.cx = cx;
            this.cz = cz;
            this.percent = percent;
            this.center = center;
            this.reasons = reasons;
        }
    }

    public static final Map<Long, Detection> RESULTS = new LinkedHashMap<>();
    private static BaseFinder instance;

    private static final int NONE = 0, ART = 1, STORAGE = 2, SPAWNER = 3, GEODE = 4, MINE = 5;
    private static final Map<Block, Integer> CODES = new HashMap<>();
    private static final String[] ART_PARTS = {"planks", "concrete", "glass", "wool", "glowstone", "sea_lantern", "crafting_table", "furnace",
            "smoker", "blast_furnace", "_bed", "door", "lantern", "sign", "bookshelf", "polished_", "_carpet", "ladder", "scaffolding",
            "beacon", "enchanting_table", "anvil", "brewing_stand", "cauldron", "bell", "torch"};

    private final Setting.Num minProb = add(new Setting.Num("Minimum Probability", "Detections below this score are hidden.", 40, 5, 95, 5, "%"));
    private final Setting.Num radius = add(new Setting.Num("Scan Radius", "How many chunks around you are analysed.", 8, 2, 16, 1, " ch"));
    private final Setting.Num interval = add(new Setting.Num("Scan Interval", "Ticks between scanning one chunk (lower = faster, more CPU).", 10, 2, 100, 2, " t"));
    private final Setting.Color color = add(new Setting.Color("Highlight Color", "Color of base candidate markers.", 4));
    private final Setting.Bool notifications = add(new Setting.Bool("Notifications", "Chat message when a new candidate above the threshold is found.", true));

    private final Map<Long, Long> scannedAt = new HashMap<>();
    private final Set<Long> notified = new HashSet<>();
    private int scannedChunks;

    public BaseFinder() {
        super("Base Finder", Category.BASE_HUNTING,
                "Scores loaded chunks for unusual rooms, artificial blocks and storage, and explains each score.",
                "Uses only chunk data your client has received; it cannot see unloaded chunks and cannot bypass server-side anti-Xray or hidden data. "
                        + "Scores are heuristics: villages, mineshafts, strongholds and dungeons can look like bases. Tuned for the Overworld; 'cleared surface area' detection is not implemented.");
        instance = this;
    }

    public static int threshold() {
        return instance == null ? 40 : instance.minProb.getInt();
    }

    public static List<Detection> sorted() {
        List<Detection> l = new ArrayList<>(RESULTS.values());
        l.sort(Comparator.comparingInt((Detection d) -> d.percent).reversed());
        return l;
    }

    @Override
    public void onEnable() {
        scannedAt.clear();
        notified.clear();
        scannedChunks = 0;
    }

    // ---------------------------------------------------------- classification
    private static int code(Block b) {
        return CODES.computeIfAbsent(b, k -> {
            String id = Util.id(k);
            if (id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel") || id.equals("hopper") || id.endsWith("shulker_box")) return STORAGE;
            if (id.equals("spawner")) return SPAWNER;
            if (id.equals("amethyst_block") || id.equals("budding_amethyst")) return GEODE;
            if (id.endsWith("rail") || id.equals("cobweb")) return MINE;
            for (String part : ART_PARTS) if (id.contains(part)) return ART;
            return NONE;
        });
    }

    private static boolean solid(BlockState s) {
        return !s.isAir() && s.getFluidState().isEmpty();
    }

    // ------------------------------------------------------------------- tick
    @Override
    public void tick(Minecraft mc) {
        if (mc.player.tickCount % Math.max(1, interval.getInt()) != 0) return;
        ClientLevel level = mc.level;
        int pcx = mc.player.blockPosition().getX() >> 4;
        int pcz = mc.player.blockPosition().getZ() >> 4;
        int r = radius.getInt();
        long now = level.getGameTime();

        int bestD = Integer.MAX_VALUE, bx = 0, bz = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int d = dx * dx + dz * dz;
                if (d > r * r || d >= bestD) continue;
                int cx = pcx + dx, cz = pcz + dz;
                if (!level.getChunkSource().hasChunk(cx, cz)) continue;
                Long at = scannedAt.get(ChunkPos.asLong(cx, cz));
                if (at != null && now - at < 1200) continue;
                bestD = d;
                bx = cx;
                bz = cz;
            }
        }
        if (bestD == Integer.MAX_VALUE) return;

        long key = ChunkPos.asLong(bx, bz);
        scannedAt.put(key, now);
        scannedChunks++;
        Detection det = scan(level, level.getChunk(bx, bz), bx, bz);
        if (det == null) {
            RESULTS.remove(key);
            return;
        }
        RESULTS.put(key, det);
        if (notifications.get() && det.percent >= minProb.getInt() && notified.add(key)) {
            Util.chat("Base candidate " + det.percent + "% near " + det.center.getX() + ", " + det.center.getZ());
        }
    }

    // ------------------------------------------------------------------- scan
    private Detection scan(ClientLevel level, LevelChunk ch, int cx, int cz) {
        int minSec = ch.getMinSectionY();
        int secCount = ch.getSectionsCount();
        int art = 0, storage = 0, spawners = 0, mine = 0;
        BlockPos geode = null;
        long sx = 0, sy = 0, sz = 0;
        int samples = 0;

        for (int si = 0; si < secCount; si++) {
            LevelChunkSection sec = ch.getSection(si);
            if (sec.hasOnlyAir()) continue;
            int baseY = (minSec + si) << 4;
            if (baseY > 140) continue;
            if (!sec.maybeHas(s -> code(s.getBlock()) != NONE)) continue;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        int c = code(sec.getBlockState(x, y, z).getBlock());
                        if (c == NONE) continue;
                        int wx = (cx << 4) + x, wy = baseY + y, wz = (cz << 4) + z;
                        switch (c) {
                            case ART -> { art++; sx += wx; sy += wy; sz += wz; samples++; }
                            case STORAGE -> { storage++; sx += wx * 3L; sy += wy * 3L; sz += wz * 3L; samples += 3; }
                            case SPAWNER -> spawners++;
                            case MINE -> mine++;
                            case GEODE -> { if (geode == null) geode = new BlockPos(wx, wy, wz); }
                            default -> { }
                        }
                    }
                }
            }
        }

        int rooms = countFlatRooms(level, ch, cx, cz);

        double pts = 0;
        List<String> why = new ArrayList<>();
        if (storage > 0) {
            double p = Math.min(35, 12 + 8 * storage);
            pts += p;
            why.add("+" + (int) p + ": " + storage + " storage block(s) (chest/barrel/shulker/hopper) loaded here");
        }
        if (art >= 6) {
            double p = Math.min(30, art * 1.5);
            pts += p;
            why.add("+" + (int) p + ": " + art + " artificial-looking blocks (planks, glass, doors, lights...)");
        }
        if (rooms > 0) {
            double p = Math.min(25, 8 * rooms);
            pts += p;
            why.add("+" + (int) p + ": " + rooms + " underground room(s) with flat floor and ceiling");
        }
        if (storage > 0 && art >= 6) {
            pts += 10;
            why.add("+10: storage together with built blocks");
        }
        if (spawners > 0 || mine >= 8) {
            pts -= 25;
            why.add("-25: " + (spawners > 0 ? "spawner" : mine + " rails/cobwebs") + " suggests a dungeon or mineshaft");
        }
        if (geode != null) {
            why.add("info: natural amethyst geode at " + geode.getX() + ", " + geode.getY() + ", " + geode.getZ() + " (not counted as a base)");
        }

        int pct = (int) Math.max(0, Math.min(100, Math.round(pts)));
        if (pct <= 0 && geode == null) return null;
        if (pct <= 0) pct = 0;

        BlockPos center = samples > 0
                ? new BlockPos((int) (sx / samples), (int) (sy / samples), (int) (sz / samples))
                : (geode != null ? geode : new BlockPos((cx << 4) + 8, 0, (cz << 4) + 8));
        if (pct == 0) return null;
        return new Detection(cx, cz, pct, center, why);
    }

    /** Counts distinct underground 3x3x2 air pockets with a fully solid, flat floor and ceiling. */
    private int countFlatRooms(ClientLevel level, LevelChunk ch, int cx, int cz) {
        Set<Long> cells = new HashSet<>();
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos();
        int yMin = level.getMinY() + 2;
        int yMax = Math.min(level.getMinY() + level.getHeight() - 4, 55);
        for (int y = yMin; y <= yMax; y++) {
            for (int x = 2; x <= 13; x += 2) {
                for (int z = 2; z <= 13; z += 2) {
                    int wx = (cx << 4) + x, wz = (cz << 4) + z;
                    if (!ch.getBlockState(m.set(wx, y, wz)).isAir()) continue;
                    if (!solid(ch.getBlockState(m.set(wx, y - 1, wz)))) continue;
                    if (!ch.getBlockState(m.set(wx, y + 1, wz)).isAir()) continue;
                    if (!flat(ch, m, wx, y, wz)) continue;
                    cells.add((((long) (wx >> 2)) << 40) ^ (((long) (y >> 2)) << 20) ^ (wz >> 2));
                    if (cells.size() >= 8) return cells.size();
                }
            }
        }
        return cells.size();
    }

    private static boolean flat(LevelChunk ch, BlockPos.MutableBlockPos m, int x, int y, int z) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (!ch.getBlockState(m.set(x + dx, y, z + dz)).isAir()) return false;
                if (!ch.getBlockState(m.set(x + dx, y + 1, z + dz)).isAir()) return false;
                if (!solid(ch.getBlockState(m.set(x + dx, y - 1, z + dz)))) return false;
                if (!solid(ch.getBlockState(m.set(x + dx, y + 2, z + dz)))) return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------- rendering
    @Override
    public void renderOverlay(Overlay o) {
        Vec3 pos = o.mc.player.position();
        for (Detection d : RESULTS.values()) {
            if (d.percent < minProb.getInt()) continue;
            Vec3 c = Vec3.atCenterOf(d.center);
            double dist = pos.distanceTo(c);
            if (dist > 400) continue;
            o.box(new AABB(c, c).inflate(1.5), color.argb(), 1);
            o.marker(c, d.percent + "% base? " + (int) dist + "m", color.argb());
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("Chunks scanned: " + scannedChunks);
        int shown = 0;
        for (Detection d : sorted()) {
            if (d.percent < minProb.getInt()) continue;
            l.add(String.format(Locale.ROOT, "%d%% at %d, %d", d.percent, d.center.getX(), d.center.getZ()));
            for (int i = 0; i < Math.min(3, d.reasons.size()); i++) l.add("  " + d.reasons.get(i));
            if (++shown >= 3) break;
        }
        if (shown == 0) l.add("No candidates above " + minProb.getInt() + "%");
        return l;
    }
}
