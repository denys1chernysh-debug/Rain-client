package com.rain.client.module.crystal;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Tracks ender pearls and wind charges in flight and draws an estimated trajectory. */
public final class WindChargePearl extends Module {
    private final Setting.Bool trajectory = add(new Setting.Bool("Trajectory Display", "Draw the predicted flight path of projectiles and of the one you hold.", true));
    private final Setting.Bool indicators = add(new Setting.Bool("Projectile Indicators", "Mark each projectile with a label and direction.", true));
    private final Setting.Bool timing = add(new Setting.Bool("Timing Feedback", "Show how long each projectile has been in flight.", true));
    private final Setting.Num steps = add(new Setting.Num("Prediction Steps", "How many ticks ahead the path is simulated.", 40, 10, 100, 5, " t"));

    private final Map<Integer, Long> firstSeen = new HashMap<>();
    private final List<Entity> tracked = new ArrayList<>();
    private int pearlsSeen, windSeen;

    public WindChargePearl() {
        super("Wind Charge & Pearl Catch", Category.CRYSTAL_MACE,
                "Tracks ender pearls and wind charges, showing direction, flight time and an estimated path.",
                "The path is an approximation from vanilla gravity/drag values and ignores entity hits, wind-charge pushes and your own momentum, so it can differ from the real flight. Information only.");
    }

    @Override
    public void onEnable() {
        firstSeen.clear();
        tracked.clear();
        pearlsSeen = windSeen = 0;
    }

    private static boolean isTracked(String id) {
        return id.equals("ender_pearl") || id.equals("wind_charge") || id.equals("breeze_wind_charge");
    }

    @Override
    public void tick(Minecraft mc) {
        tracked.clear();
        Set<Integer> now = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            String id = Util.id(e);
            if (!isTracked(id)) continue;
            if (mc.player.distanceTo(e) > 64) continue;
            tracked.add(e);
            now.add(e.getId());
            if (!firstSeen.containsKey(e.getId())) {
                firstSeen.put(e.getId(), System.currentTimeMillis());
                if (id.equals("ender_pearl")) pearlsSeen++;
                else windSeen++;
            }
        }
        firstSeen.keySet().retainAll(now);
    }

    private static List<Vec3> simulate(Level level, Vec3 start, Vec3 vel, double gravity, double drag, int n) {
        List<Vec3> out = new ArrayList<>();
        Vec3 pos = start, v = vel;
        for (int i = 0; i < n; i++) {
            pos = pos.add(v);
            BlockState s = level.getBlockState(BlockPos.containing(pos));
            if (!s.isAir()) break;
            out.add(pos);
            v = v.scale(drag).add(0, -gravity, 0);
        }
        return out;
    }

    private static double gravityOf(String id) {
        return id.equals("ender_pearl") ? 0.03 : 0.0;
    }

    private static double dragOf(String id) {
        return id.equals("ender_pearl") ? 0.99 : 1.0;
    }

    private void drawPath(Overlay o, List<Vec3> path, int argb) {
        int i = 0;
        for (Vec3 p : path) {
            double[] s = o.project(p);
            if (s != null && (i % 2 == 0)) o.rect((int) s[0] - 1, (int) s[1] - 1, (int) s[0] + 1, (int) s[1] + 1, argb);
            i++;
        }
    }

    @Override
    public void renderOverlay(Overlay o) {
        LocalPlayer p = o.mc.player;
        for (Entity e : tracked) {
            String id = Util.id(e);
            Vec3 v = e.getDeltaMovement();
            if (indicators.get()) {
                String label = (id.equals("ender_pearl") ? "Pearl" : "Wind") + (timing.get() ? " " + Util.f1((System.currentTimeMillis() - firstSeen.getOrDefault(e.getId(), System.currentTimeMillis())) / 1000.0) + "s" : "");
                o.marker(e.position(), label, 0xFFE8EAED);
                Vec3 tip = e.position().add(v.normalize().scale(1.2));
                o.marker(tip, null, 0xFFE6C84A);
            }
            if (trajectory.get()) {
                drawPath(o, simulate(o.mc.level, e.position(), v, gravityOf(id), dragOf(id), steps.getInt()), 0xFFC8CDD4);
            }
        }
        if (trajectory.get()) {
            String held = Util.id(p.getMainHandItem());
            if (held.equals("ender_pearl") || held.equals("wind_charge")) {
                Vec3 start = p.getEyePosition(o.pt).add(0, -0.1, 0);
                Vec3 vel = p.getLookAngle().scale(1.5);
                drawPath(o, simulate(o.mc.level, start, vel, gravityOf(held), dragOf(held), steps.getInt()), 0xFF4FC3D9);
            }
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("In flight: " + tracked.size());
        l.add("Pearls seen: " + pearlsSeen + "  Wind charges: " + windSeen);
        if (timing.get() && !tracked.isEmpty()) {
            long oldest = 0;
            for (Entity e : tracked) oldest = Math.max(oldest, System.currentTimeMillis() - firstSeen.getOrDefault(e.getId(), System.currentTimeMillis()));
            l.add("Longest flight now: " + Util.f1(oldest / 1000.0) + " s");
        }
        return l;
    }
}
