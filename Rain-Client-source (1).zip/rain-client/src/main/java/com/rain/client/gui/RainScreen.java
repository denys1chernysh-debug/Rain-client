package com.rain.client.gui;

import com.rain.client.Config;
import com.rain.client.RainClient;
import com.rain.client.UiSettings;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.ModuleManager;
import com.rain.client.module.Setting;
import com.rain.client.util.Keys;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/**
 * The Rain GUI. Immediate-mode: every frame the layout is rebuilt and clickable regions are
 * registered while drawing, so there is no widget state to keep in sync.
 * Pages 0-2 are the module categories, page 3 is Settings.
 */
public final class RainScreen extends Screen {
    private static final int SETTINGS_PAGE = 3;

    // palette (monochrome)
    private static final int PANEL = 0x15171B;
    private static final int CARD = 0x2A2D33;
    private static final int CARD_HI = 0x3A3E46;
    private static final int LINE = 0x3E434B;
    private static final int TEXT = 0xF0F2F5;
    private static final int DIM = 0x9AA0A9;
    private static final int ON = 0xE4E7EB;
    private static final int OFF = 0x5A5F68;
    private static final int ERR = 0xE5534B;

    private record Region(int x1, int y1, int x2, int y2, IntConsumer click, DoubleConsumer drag, String tip) {}

    private final List<Region> regions = new ArrayList<>();
    private DoubleConsumer activeDrag;
    private int page = Math.min(UiSettings.category, SETTINGS_PAGE);
    private String search = "";
    private boolean searchFocus;
    private double scroll;
    private int contentHeight, viewTop, viewBottom;
    private Module listening;
    private String tip = "";
    private int mx, my;

    public RainScreen() {
        super(Component.literal("Rain"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void removed() {
        Config.save();
    }

    // ------------------------------------------------------------- colours
    private static double bgAlpha() { return 1.0 - UiSettings.backgroundTransparency / 100.0; }
    private static double btnAlpha() { return 1.0 - UiSettings.buttonTransparency / 100.0; }

    /** rgb + alpha (0..1), multiplied by Interface Opacity. */
    private static int c(int rgb, double a) {
        double v = Math.max(0, Math.min(1, a)) * UiSettings.interfaceOpacity / 100.0;
        int al = (int) Math.round(v * 255.0);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    private void roundRect(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int color) {
        g.fill(x1 + 2, y1, x2 - 2, y2, color);
        g.fill(x1 + 1, y1 + 1, x1 + 2, y2 - 1, color);
        g.fill(x2 - 2, y1 + 1, x2 - 1, y2 - 1, color);
        g.fill(x1, y1 + 2, x1 + 1, y2 - 2, color);
        g.fill(x2 - 1, y1 + 2, x2, y2 - 2, color);
    }

    private String fit(String s, int w) {
        if (font.width(s) <= w) return s;
        while (s.length() > 1 && font.width(s + "...") > w) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    private List<String> wrap(String s, int w) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String test = line.length() == 0 ? word : line + " " + word;
            if (font.width(test) > w && line.length() > 0) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(test);
            }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    private boolean hover(int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2 && my >= viewTopClip() && my < viewBottomClip(y1);
    }

    private int viewTopClip() { return 0; }
    private int viewBottomClip(int y1) { return Integer.MAX_VALUE; }

    private void region(int x1, int y1, int x2, int y2, IntConsumer click, DoubleConsumer drag, String tipText, boolean scrolled) {
        int ry1 = y1, ry2 = y2;
        if (scrolled) {
            ry1 = Math.max(y1, viewTop);
            ry2 = Math.min(y2, viewBottom);
            if (ry2 <= ry1) return;
        }
        regions.add(new Region(x1, ry1, x2, ry2, click, drag, tipText));
        if (tipText != null && mx >= x1 && mx < x2 && my >= ry1 && my < ry2) tip = tipText;
    }

    // --------------------------------------------------------------- render
    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        mx = mouseX;
        my = mouseY;
        regions.clear();
        tip = "";

        int w = Math.min(width - 24, 900);
        int h = Math.min(height - 24, 560);
        int x0 = (width - w) / 2, y0 = (height - h) / 2;
        int side = 150;

        // window + sidebar
        roundRect(g, x0 - 1, y0 - 1, x0 + w + 1, y0 + h + 1, c(LINE, 0.55));
        roundRect(g, x0, y0, x0 + w, y0 + h, c(PANEL, bgAlpha()));
        roundRect(g, x0 + 6, y0 + 6, x0 + side - 4, y0 + h - 6, c(0x000000, bgAlpha() * 0.35));

        g.text(font, "Rain", x0 + 20, y0 + 16, c(TEXT, 1));
        g.text(font, "v" + RainClient.VERSION, x0 + 20, y0 + 28, c(DIM, 1));

        int ny = y0 + 52;
        for (int i = 0; i <= SETTINGS_PAGE; i++) {
            String label = i < 3 ? Category.values()[i].label : "Settings";
            int by = i < 3 ? ny + i * 28 : y0 + h - 40;
            int x1 = x0 + 12, x2 = x0 + side - 10;
            boolean sel = page == i && search.isEmpty();
            boolean hv = mx >= x1 && mx < x2 && my >= by && my < by + 24;
            if (sel) roundRect(g, x1, by, x2, by + 24, c(CARD_HI, Math.max(0.35, btnAlpha() + 0.15)));
            else if (hv) roundRect(g, x1, by, x2, by + 24, c(CARD, Math.max(0.2, btnAlpha() * 0.6)));
            g.text(font, label, x1 + 12, by + 8, c(sel ? TEXT : DIM, 1));
            final int target = i;
            region(x1, by, x2, by + 24, b -> {
                page = target;
                UiSettings.category = target;
                scroll = 0;
                search = "";
                listening = null;
                Config.markDirty();
            }, null, null, false);
        }

        int cx1 = x0 + side + 10, cx2 = x0 + w - 14;
        if (page == SETTINGS_PAGE && search.isEmpty()) drawSettingsPage(g, cx1, y0 + 14, cx2, y0 + h - 14);
        else drawModulePage(g, cx1, y0 + 14, cx2, y0 + h - 14);

        if (!tip.isEmpty()) {
            String t = fit(tip, cx2 - cx1);
            g.text(font, t, cx1, y0 + h - 12, c(DIM, 1));
        }
    }

    // ------------------------------------------------------- module pages
    private void drawModulePage(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2) {
        boolean searching = !search.isEmpty();
        List<Module> list = searching ? ModuleManager.search(search) : ModuleManager.in(Category.values()[page]);
        String title = searching ? "Search" : Category.values()[page].label;
        String sub = searching ? list.size() + " result(s) across all categories" : Category.values()[page].subtitle;

        g.text(font, title, x1, y1 + 4, c(TEXT, 1));
        g.text(font, fit(sub, x2 - x1 - 230), x1, y1 + 18, c(DIM, 1));

        // search box
        int sw = 210, sx1 = x2 - sw, sy1 = y1;
        roundRect(g, sx1, sy1, x2, sy1 + 22, c(CARD, Math.max(0.25, btnAlpha())));
        if (searchFocus) {
            int oc = c(ON, 0.6);
            g.fill(sx1 + 2, sy1, x2 - 2, sy1 + 1, oc);
            g.fill(sx1 + 2, sy1 + 21, x2 - 2, sy1 + 22, oc);
            g.fill(sx1, sy1 + 2, sx1 + 1, sy1 + 20, oc);
            g.fill(x2 - 1, sy1 + 2, x2, sy1 + 20, oc);
        }
        boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
        String shown = search.isEmpty() && !searchFocus ? "Search modules... (Ctrl+K)" : search + (searchFocus && blink ? "|" : "");
        g.text(font, fit(shown, sw - 16), sx1 + 8, sy1 + 7, c(search.isEmpty() && !searchFocus ? DIM : TEXT, 1));
        region(sx1, sy1, x2, sy1 + 22, b -> { searchFocus = true; listening = null; }, null, null, false);

        viewTop = y1 + 34;
        viewBottom = y2 - 14;
        g.enableScissor(x1, viewTop, x2, viewBottom);
        int y = viewTop - (int) scroll;
        int startY = y;
        if (list.isEmpty()) {
            g.text(font, "No modules found.", x1 + 4, y + 6, c(DIM, 1));
            y += 20;
        }
        for (Module m : list) y += drawModule(g, m, x1, y, x2) + 6;
        g.disableScissor();
        contentHeight = y - startY;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - (viewBottom - viewTop))));
        drawScrollbar(g, x2 + 4, viewTop, viewBottom);
    }

    private void drawScrollbar(GuiGraphicsExtractor g, int x, int top, int bottom) {
        int vh = bottom - top;
        if (contentHeight <= vh) return;
        int th = Math.max(20, vh * vh / contentHeight);
        int ty = top + (int) ((vh - th) * (scroll / (contentHeight - vh)));
        g.fill(x, top, x + 3, bottom, c(0x000000, 0.25));
        g.fill(x, ty, x + 3, ty + th, c(DIM, 0.8));
    }

    private int drawModule(GuiGraphicsExtractor g, Module m, int x1, int y, int x2) {
        int headH = 34;
        int top = y;
        double cardA = Math.max(0.12, btnAlpha());
        boolean hv = hover(x1, y, x2, y + headH) && my >= viewTop && my < viewBottom;
        int bodyH = m.expanded ? bodyHeight(m, x2 - x1 - 24) : 0;

        roundRect(g, x1, y, x2, y + headH + bodyH, c(hv ? CARD_HI : CARD, cardA));

        g.text(font, m.name, x1 + 14, y + 7, c(TEXT, 1));
        g.text(font, fit(m.description, x2 - x1 - 110), x1 + 14, y + 19, c(DIM, 1));
        if (!m.lastError.isEmpty()) g.text(font, "!", x2 - 78, y + 12, c(ERR, 1));

        // toggle
        int tx2 = x2 - 14, tx1 = tx2 - 30;
        drawToggle(g, tx1, y + 10, m.enabled);
        region(tx1, y + 6, tx2, y + 28, b -> { m.toggle(); Config.markDirty(); }, null, "Enable / disable " + m.name, true);
        // expand arrow
        g.text(font, m.expanded ? "v" : ">", tx1 - 16, y + 13, c(DIM, 1));
        region(x1, y, tx1 - 4, y + headH, b -> m.expanded = !m.expanded, null, m.description, true);

        if (!m.expanded) return headH;
        y += headH;
        int ix1 = x1 + 14, ix2 = x2 - 14;
        g.fill(ix1, y, ix2, y + 1, c(LINE, 0.6));
        y += 6;

        for (String line : wrap("Limitations: " + m.limitation, ix2 - ix1)) {
            g.text(font, line, ix1, y, c(DIM, 1));
            y += 10;
        }
        if (!m.lastError.isEmpty()) {
            for (String line : wrap("Error: " + m.lastError, ix2 - ix1)) {
                g.text(font, line, ix1, y, c(ERR, 1));
                y += 10;
            }
        }
        y += 6;

        for (Setting s : m.settings) y += drawSetting(g, s, ix1, y, ix2);

        // keybind row
        g.text(font, "Keybind", ix1, y + 6, c(TEXT, 1));
        String kb = listening == m ? "press a key..." : Keys.name(m.keybind);
        drawButton(g, ix2 - 110, y, ix2, y + 18, kb);
        region(ix2 - 110, y, ix2, y + 18, b -> {
            if (b == 1) { m.keybind = -1; listening = null; Config.markDirty(); }
            else listening = m;
        }, null, "Click, then press a key. Right-click clears. Esc cancels.", true);
        y += 24;

        // reset
        drawButton(g, ix1, y, ix1 + 120, y + 18, "Reset Module");
        region(ix1, y, ix1 + 120, y + 18, b -> {
            boolean was = m.enabled;
            m.reset();
            if (was) m.setEnabled(false);
            Config.markDirty();
        }, null, "Restore this module's defaults and disable it.", true);

        return headH + bodyH;
    }

    private int bodyHeight(Module m, int innerW) {
        int h = 6;
        h += wrap("Limitations: " + m.limitation, innerW).size() * 10;
        if (!m.lastError.isEmpty()) h += wrap("Error: " + m.lastError, innerW).size() * 10;
        h += 6;
        for (Setting s : m.settings) h += settingHeight(s, innerW);
        h += 24 + 24;
        return h;
    }

    // ----------------------------------------------------------- settings
    private int settingHeight(Setting s, int w) {
        if (s instanceof Setting.Num) return 28;
        if (s instanceof Setting.Multi mu) return 16 + chipRows(mu, w) * 18 + 6;
        return 24;
    }

    private int chipRows(Setting.Multi mu, int w) {
        int rows = 1, x = 0;
        for (String o : mu.options) {
            int cw = font.width(o) + 14;
            if (x + cw > w && x > 0) { rows++; x = 0; }
            x += cw + 4;
        }
        return rows;
    }

    private int drawSetting(GuiGraphicsExtractor g, Setting s, int x1, int y, int x2) {
        int h = settingHeight(s, x2 - x1);
        if (s instanceof Setting.Bool b) {
            g.text(font, b.name, x1, y + 6, c(TEXT, 1));
            drawToggle(g, x2 - 30, y + 4, b.value);
            region(x1, y, x2, y + 22, k -> { b.value = !b.value; Config.markDirty(); }, null, b.description, true);
        } else if (s instanceof Setting.Num n) {
            g.text(font, n.name, x1, y + 2, c(TEXT, 1));
            String v = n.text();
            g.text(font, v, x2 - font.width(v), y + 2, c(DIM, 1));
            drawSlider(g, x1, y + 16, x2, (n.value - n.min) / (n.max - n.min));
            region(x1, y + 10, x2, y + 26, k -> {}, mxp -> { n.set(n.min + clamp01((mxp - x1) / (double) (x2 - x1)) * (n.max - n.min)); Config.markDirty(); }, n.description, true);
        } else if (s instanceof Setting.Mode m) {
            g.text(font, m.name, x1, y + 6, c(TEXT, 1));
            drawButton(g, x2 - 130, y + 1, x2, y + 19, "< " + fit(m.get(), 100) + " >");
            region(x2 - 130, y + 1, x2, y + 19, k -> { m.cycle(k == 1 ? -1 : 1); Config.markDirty(); }, null, m.description + "  (right-click: previous)", true);
        } else if (s instanceof Setting.Multi mu) {
            g.text(font, mu.name, x1, y + 2, c(TEXT, 1));
            int cx = x1, cy = y + 16;
            for (int i = 0; i < mu.options.length; i++) {
                String o = mu.options[i];
                int cw = font.width(o) + 14;
                if (cx + cw > x2 && cx > x1) { cx = x1; cy += 18; }
                final int idx = i;
                boolean on = mu.on[i];
                roundRect(g, cx, cy, cx + cw, cy + 15, c(on ? ON : CARD_HI, on ? 0.9 : Math.max(0.3, btnAlpha())));
                g.text(font, o, cx + 7, cy + 4, c(on ? 0x15171B : DIM, 1));
                region(cx, cy, cx + cw, cy + 15, k -> { mu.on[idx] = !mu.on[idx]; Config.markDirty(); }, null, mu.description, true);
                cx += cw + 4;
            }
        } else if (s instanceof Setting.Action a) {
            drawButton(g, x1, y + 2, x2, y + 20, a.name);
            region(x1, y + 2, x2, y + 20, k -> a.run.run(), null, a.description, true);
        }
        return h;
    }

    // --------------------------------------------------------- settings page
    private void drawSettingsPage(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2) {
        g.text(font, "Settings", x1, y1 + 4, c(TEXT, 1));
        g.text(font, "Customize your client.", x1, y1 + 18, c(DIM, 1));

        viewTop = y1 + 34;
        viewBottom = y2 - 14;
        g.enableScissor(x1, viewTop, x2, viewBottom);
        int y = viewTop - (int) scroll;
        int start = y;
        int ix2 = Math.min(x2, x1 + 460);

        g.text(font, "Appearance", x1, y, c(TEXT, 1));
        y += 16;
        y = uiSlider(g, "Interface Opacity", UiSettings.interfaceOpacity, 10, 100, x1, y, ix2, v -> UiSettings.interfaceOpacity = v,
                "Opacity of the whole interface, including text (10-100%).");
        y = uiSlider(g, "Button Transparency", UiSettings.buttonTransparency, 0, 100, x1, y, ix2, v -> UiSettings.buttonTransparency = v,
                "Transparency of cards, buttons and pills (0-100%). Independent of the other two.");
        y = uiSlider(g, "Background Transparency", UiSettings.backgroundTransparency, 0, 100, x1, y, ix2, v -> UiSettings.backgroundTransparency = v,
                "Transparency of the window and sidebar panels (0-100%). Independent of the other two.");
        y += 6;
        drawButton(g, x1, y, x1 + 150, y + 20, "Reset Appearance");
        region(x1, y, x1 + 150, y + 20, b -> { UiSettings.reset(); Config.markDirty(); }, null, "Restore the three transparency values to their defaults.", true);
        drawButton(g, x1 + 160, y, x1 + 310, y + 20, "Reset All Modules");
        region(x1 + 160, y, x1 + 310, y + 20, b -> {
            for (Module m : ModuleManager.ALL) {
                if (m.enabled) m.setEnabled(false);
                m.reset();
            }
            Config.markDirty();
        }, null, "Disable every module and restore all module settings and keybinds.", true);
        y += 34;

        g.text(font, "Info", x1, y, c(TEXT, 1));
        y += 14;
        String[] info = {
                "Open / close this menu: Right Shift",
                "Modules: " + ModuleManager.ALL.size() + "   Config: .minecraft/config/rain-client.json (autosaved)",
                "Camera-moving modules only run in singleplayer worlds.",
                "Base analysis uses only data the server has sent your client."
        };
        for (String s : info) {
            g.text(font, fit(s, ix2 - x1), x1, y, c(DIM, 1));
            y += 12;
        }
        y += 6;

        g.disableScissor();
        contentHeight = y - start;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentHeight - (viewBottom - viewTop))));
        drawScrollbar(g, x2 + 4, viewTop, viewBottom);
    }

    private int uiSlider(GuiGraphicsExtractor g, String name, int value, int min, int max, int x1, int y, int x2, java.util.function.IntConsumer setter, String tipText) {
        g.text(font, name, x1, y, c(TEXT, 1));
        String v = value + "%";
        g.text(font, v, x2 - font.width(v), y, c(DIM, 1));
        drawSlider(g, x1, y + 14, x2, (value - min) / (double) (max - min));
        region(x1, y + 8, x2, y + 24, k -> {}, mxp -> {
            setter.accept(UiSettings.clamp((int) Math.round(min + clamp01((mxp - x1) / (double) (x2 - x1)) * (max - min)), min, max));
            Config.markDirty();
        }, tipText, true);
        return y + 30;
    }

    // ------------------------------------------------------------ widgets
    private static double clamp01(double v) { return Math.max(0, Math.min(1, v)); }

    private void drawToggle(GuiGraphicsExtractor g, int x, int y, boolean on) {
        roundRect(g, x, y, x + 30, y + 14, c(on ? ON : OFF, on ? 0.85 : Math.max(0.35, btnAlpha())));
        int kx = on ? x + 17 : x + 3;
        roundRect(g, kx, y + 3, kx + 10, y + 11, c(on ? 0x15171B : 0xFFFFFF, 0.95));
    }

    private void drawSlider(GuiGraphicsExtractor g, int x1, int y, int x2, double frac) {
        frac = clamp01(frac);
        g.fill(x1, y, x2, y + 4, c(OFF, Math.max(0.3, btnAlpha())));
        int fx = x1 + (int) ((x2 - x1) * frac);
        g.fill(x1, y, fx, y + 4, c(ON, 0.8));
        roundRect(g, fx - 4, y - 3, fx + 4, y + 7, c(0xFFFFFF, 0.95));
    }

    private void drawButton(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, String label) {
        boolean hv = mx >= x1 && mx < x2 && my >= y1 && my < y2 && my >= viewTop && my < viewBottom;
        roundRect(g, x1, y1, x2, y2, c(hv ? CARD_HI : CARD, Math.max(0.3, btnAlpha() + (hv ? 0.15 : 0))));
        g.text(font, label, x1 + (x2 - x1 - font.width(label)) / 2, y1 + (y2 - y1 - 8) / 2, c(TEXT, 1));
    }

    // -------------------------------------------------------------- input
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double px = event.x(), py = event.y();
        int button = event.button();
        searchFocus = false;
        if (listening != null) listening = null;
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (px >= r.x1() && px < r.x2() && py >= r.y1() && py < r.y2()) {
                r.click().accept(button);
                if (r.drag() != null) {
                    activeDrag = r.drag();
                    activeDrag.accept(px);
                }
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (activeDrag != null) {
            activeDrag.accept(event.x());
            return true;
        }
        return super.mouseDragged(event, dx, dy);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        activeDrag = null;
        Config.markDirty();
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double scrollX, double scrollY) {
        scroll = Math.max(0, Math.min(scroll - scrollY * 26, Math.max(0, contentHeight - (viewBottom - viewTop))));
        return true;
    }

    @Override
    public boolean charTyped(CharacterEvent event) {
        if (searchFocus) {
            String s = event.codepointAsString();
            if (!s.isEmpty() && search.length() < 40) {
                search += s;
                scroll = 0;
            }
            return true;
        }
        return super.charTyped(event);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();

        if (listening != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                // cancel
            } else if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) {
                listening.keybind = -1;
            } else {
                listening.keybind = key;
            }
            listening = null;
            Config.markDirty();
            return true;
        }

        boolean ctrl = (event.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0;
        if (ctrl && key == GLFW.GLFW_KEY_K) {
            searchFocus = true;
            return true;
        }

        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!search.isEmpty()) search = search.substring(0, search.length() - 1);
                scroll = 0;
                return true;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER) {
                searchFocus = false;
                if (key == GLFW.GLFW_KEY_ESCAPE && !search.isEmpty()) search = "";
                return true;
            }
            return true;
        }

        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }
}
