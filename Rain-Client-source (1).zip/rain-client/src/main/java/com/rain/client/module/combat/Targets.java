package com.rain.client.module.combat;

import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Shared target selection helpers for the combat practice modules. */
public final class Targets {
    public static final String[] PRIORITIES = {"Distance", "Crosshair", "Lowest Health"};
    public static final String[] TYPES = {"Players", "Hostile", "Passive", "Armor Stands", "Other"};

    private Targets() {}

    public static String category(Entity e) {
        if (e instanceof Player) return "Players";
        if (Util.id(e).equals("armor_stand")) return "Armor Stands";
        MobCategory c = e.getType().getCategory();
        if (c == MobCategory.MONSTER) return "Hostile";
        if (c == MobCategory.CREATURE || c == MobCategory.AMBIENT || c == MobCategory.WATER_CREATURE || c == MobCategory.AXOLOTLS) return "Passive";
        return "Other";
    }

    public static boolean typeAllowed(Setting.Multi types, Entity e) {
        return types.has(category(e));
    }

    public static boolean eligible(LocalPlayer p, Entity e, boolean includePlayers) {
        if (e == p || !(e instanceof LivingEntity le) || !le.isAlive()) return false;
        return includePlayers || !(e instanceof Player);
    }

    public static float yawTo(Vec3 from, Vec3 to) {
        double dx = to.x - from.x, dz = to.z - from.z;
        return Mth.wrapDegrees((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
    }

    public static float pitchTo(Vec3 from, Vec3 to) {
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
        return (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
    }

    /** Angular distance (degrees) between the current view direction and a world point. */
    public static double angle(LocalPlayer p, Vec3 eye, Vec3 point) {
        double dy = Mth.wrapDegrees(yawTo(eye, point) - p.getYRot());
        double dp = pitchTo(eye, point) - p.getXRot();
        return Math.sqrt(dy * dy + dp * dp);
    }

    public static boolean visible(Minecraft mc, Vec3 from, Vec3 to) {
        HitResult r = mc.level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
        return r.getType() == HitResult.Type.MISS;
    }

    /**
     * Picks the best eligible target. mode: 0 distance, 1 angle to crosshair, 2 lowest health.
     * fov is the full cone width in degrees.
     */
    public static Entity best(Minecraft mc, double range, double fov, int mode, boolean includePlayers, boolean needVisible) {
        LocalPlayer p = mc.player;
        Vec3 eye = p.getEyePosition();
        Entity best = null;
        double bestScore = Double.MAX_VALUE;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!eligible(p, e, includePlayers)) continue;
            double d = p.distanceTo(e);
            if (d > range) continue;
            Vec3 c = e.getBoundingBox().getCenter();
            double ang = angle(p, eye, c);
            if (ang > fov / 2.0) continue;
            if (needVisible && !visible(mc, eye, c)) continue;
            double score = switch (mode) {
                case 1 -> ang;
                case 2 -> ((LivingEntity) e).getHealth();
                default -> d;
            };
            if (score < bestScore) {
                bestScore = score;
                best = e;
            }
        }
        return best;
    }

    public static String describe(Entity e) {
        return Util.pretty(Util.id(e)) + (e instanceof Player pl ? " (" + pl.getName().getString() + ")" : "");
    }
}
