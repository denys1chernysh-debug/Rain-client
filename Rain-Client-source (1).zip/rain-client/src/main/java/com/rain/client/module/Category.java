package com.rain.client.module;

public enum Category {
    COMBAT("Combat", "Practice, timing and analysis tools for sword PvP."),
    CRYSTAL_MACE("Crystal & Mace", "Crystal, anchor, totem, mace and projectile training tools."),
    BASE_HUNTING("Base Hunting", "Analysis of the world data your client has actually received.");

    public final String label;
    public final String subtitle;

    Category(String label, String subtitle) {
        this.label = label;
        this.subtitle = subtitle;
    }
}
