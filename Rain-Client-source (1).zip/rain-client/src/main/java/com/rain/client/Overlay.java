package com.rain.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Per-frame drawing helper for in-game overlays.
 * <p>
 * World markers and boxes are drawn as 2D screen-space shapes, using our own perspective
 * projection built from the player's eye position, view angles and the FOV option. This avoids
 * depending on the (heavily reworked) 26.x world-render API. Limits: first-person only, and the
 * projection ignores temporary FOV changes (sprinting, potions, zoom).
 */
public final class Overlay {
    public final GuiGraphicsExtractor g;
    public final Minecraft mc;
    public final Font font;
    public final float pt;
    public final int w, h;
    /** False in third person: projected drawing is skipped because the camera is not at the eyes. */
    public final boolean valid;

    private final double ex, ey, ez;
    private final double fx, fy, fz;
    private final double rx, rz;
    private final double ux, uy, uz;
    private final double tanHalf, aspect;

    public Overlay(GuiGraphicsExtractor g, Minecraft mc, float pt) {
        this.g = g;
        this.mc = mc;
        this.font = mc.font;
        this.pt = pt;
        this.w = mc.getWindow().getGuiScaledWidth();
        this.h = mc.getWindow().getGuiScaledHeight();

        LocalPlayer p = mc.player;
        Vec3 eye = p.getEyePosition(pt);
        ex = eye.x;
        ey = eye.y;
        ez = eye.z;

        double yaw = Math.toRadians(p.getViewYRot(pt));
        double pitch = Math.toRadians(p.getViewXRot(pt));
        fx = -Math.sin(yaw) * Math.cos(pitch);
        fy = -Math.sin(pitch);
        fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw);
        rz = -Math.sin(yaw);
        // up = right x forward (right has no Y component)
        ux = -rz * fy;
        uy = rz * fx - rx * fz;
        uz = rx * fy;

        double fov = mc.options.fov().get();
        tanHalf = Math.tan(Math.toRadians(fov) / 2.0);
        aspect = (double) w / (double) h;
        valid = mc.options.getCameraType().isFirstPerson();
    }

    /** @return {screenX, screenY, depth} or null if behind the camera / not first person. */
    public double[] project(double x, double y, double z) {
        if (!valid) return null;
        double dx = x - ex, dy = y - ey, dz = z - ez;
        double depth = dx * fx + dy * fy + dz * fz;
        if (depth < 0.05) return null;
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        double sx = w / 2.0 + (xc / depth) / (tanHalf * aspect) * (w / 2.0);
        double sy = h / 2.0 - (yc / depth) / tanHalf * (h / 2.0);
        return new double[]{sx, sy, depth};
    }

    public double[] project(Vec3 v) {
        return project(v.x, v.y, v.z);
    }

    // ----------------------------------------------------------- primitives
    public void rect(int x1, int y1, int x2, int y2, int argb) {
        g.fill(x1, y1, x2, y2, argb);
    }

    public void outline(int x1, int y1, int x2, int y2, int thick, int argb) {
        g.fill(x1, y1, x2, y1 + thick, argb);
        g.fill(x1, y2 - thick, x2, y2, argb);
        g.fill(x1, y1 + thick, x1 + thick, y2 - thick, argb);
        g.fill(x2 - thick, y1 + thick, x2, y2 - thick, argb);
    }

    public void text(String s, int x, int y, int argb) {
        g.text(font, s, x, y, argb);
    }

    public int width(String s) {
        return font.width(s);
    }

    public void centered(String s, int cx, int y, int argb) {
        g.text(font, s, cx - font.width(s) / 2, y, argb);
    }

    // ------------------------------------------------------ projected shapes
    /** Draws the screen-space bounding rectangle of a world AABB. @return false if it could not be drawn. */
    public boolean box(AABB b, int argb, int thick) {
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? b.minX : b.maxX;
            double y = (i & 2) == 0 ? b.minY : b.maxY;
            double z = (i & 4) == 0 ? b.minZ : b.maxZ;
            double[] p = project(x, y, z);
            if (p == null) return false;
            minX = Math.min(minX, p[0]);
            maxX = Math.max(maxX, p[0]);
            minY = Math.min(minY, p[1]);
            maxY = Math.max(maxY, p[1]);
        }
        if (maxX - minX > w * 3 || maxY - minY > h * 3) return false;
        if (maxX < 0 || minX > w || maxY < 0 || minY > h) return false;
        outline((int) minX, (int) minY, (int) maxX, (int) maxY, Math.max(1, thick), argb);
        return true;
    }

    /** Draws a small marker with a centered label at a world position. */
    public boolean marker(Vec3 pos, String label, int argb) {
        double[] p = project(pos);
        if (p == null) return false;
        int x = (int) p[0], y = (int) p[1];
        if (x < -50 || x > w + 50 || y < -50 || y > h + 50) return false;
        rect(x - 2, y - 2, x + 3, y + 3, argb);
        if (label != null && !label.isEmpty()) centered(label, x, y - 12, argb);
        return true;
    }
}
