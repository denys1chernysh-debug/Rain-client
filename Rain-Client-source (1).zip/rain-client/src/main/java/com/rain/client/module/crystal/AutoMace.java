package com.rain.client.module.crystal;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

import java.util.ArrayList;
import java.util.List;

/** Mace smash-attack timing display. It never attacks. */
public final class AutoMace extends Module {
    private final Setting.Bool fallIndicator = add(new Setting.Bool("Fall Indicator", "Draw a fall-distance bar under the crosshair.", true));
    private final Setting.Bool timingDisplay = add(new Setting.Bool("Timing Display", "Show airborne time and estimated smash bonus.", true));
    private final Setting.Bool maceHud = add(new Setting.Bool("Mace HUD", "Show the HUD panel while a mace is held.", true));

    private boolean holding;
    private boolean airborne;
    private double peakY, fall;
    private long airSince, airMs;

    public AutoMace() {
        super("Auto Mace", Category.CRYSTAL_MACE,
                "While you hold a mace, tracks your fall and shows when a smash attack would be worth it.",
                "Display only; it never attacks. Fall distance is measured by your client from height changes. The bonus is the vanilla formula estimate (the server decides the real damage).");
    }

    @Override
    public void onEnable() {
        airborne = false;
        fall = 0;
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        holding = Util.id(p.getMainHandItem()).equals("mace");
        boolean ground = p.onGround();
        double y = p.getY();
        if (ground) {
            airborne = false;
            fall = 0;
            airMs = 0;
        } else {
            if (!airborne) {
                airborne = true;
                peakY = y;
                airSince = System.currentTimeMillis();
            }
            peakY = Math.max(peakY, y);
            fall = peakY - y;
            airMs = System.currentTimeMillis() - airSince;
        }
    }

    /** Vanilla mace bonus damage: 4/block for the first 3, 2/block up to 8, then 1/block. */
    static double bonus(double f) {
        if (f <= 1.5) return 0;
        if (f <= 3) return 4 * f;
        if (f <= 8) return 12 + 2 * (f - 3);
        return 22 + (f - 8);
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (!holding || !fallIndicator.get()) return;
        int cx = o.w / 2, cy = o.h / 2 + 48, bw = 80;
        o.rect(cx - bw / 2, cy, cx + bw / 2, cy + 5, 0x90101216);
        int fill = (int) Math.min(bw, fall / 10.0 * bw);
        boolean good = fall > 1.5;
        o.rect(cx - bw / 2, cy, cx - bw / 2 + fill, cy + 5, good ? 0xFF5CC46B : 0xFF8A9099);
        o.centered(good ? "SMASH READY  " + Util.f1(fall) + " m" : "fall " + Util.f1(fall) + " m", cx, cy + 8, good ? 0xFF5CC46B : 0xFFB4BAC2);
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        if (!holding) {
            if (!maceHud.get()) return l;
            l.add("Hold a mace");
            return l;
        }
        if (!maceHud.get()) return l;
        l.add("Mace: held");
        l.add("Airborne: " + (airborne ? "yes" : "no"));
        if (timingDisplay.get()) {
            l.add("Fall: " + Util.f1(fall) + " m   Air time: " + airMs + " ms");
            l.add("Est. smash bonus: +" + Util.f1(bonus(fall)) + " dmg" + (fall > 1.5 ? "" : " (needs >1.5 m)"));
        }
        return l;
    }
}
