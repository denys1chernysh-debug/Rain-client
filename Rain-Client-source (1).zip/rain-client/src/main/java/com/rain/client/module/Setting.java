package com.rain.client.module;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

/** Base class for all module settings. Each subtype knows how to reset and persist itself. */
public abstract class Setting {
    public final String name;
    public final String description;

    protected Setting(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public abstract void reset();

    /** @return JSON value to persist, or null if this setting is not persisted. */
    public abstract JsonElement save();

    public abstract void load(JsonElement e);

    // ------------------------------------------------------------------ Bool
    public static final class Bool extends Setting {
        public boolean value;
        private final boolean def;

        public Bool(String name, String description, boolean def) {
            super(name, description);
            this.def = def;
            this.value = def;
        }

        public boolean get() {
            return value;
        }

        @Override public void reset() { value = def; }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) {
            if (e != null && e.isJsonPrimitive()) value = e.getAsBoolean();
        }
    }

    // ------------------------------------------------------------------- Num
    public static final class Num extends Setting {
        public double value;
        private final double def;
        public final double min, max, step;
        public final String unit;

        public Num(String name, String description, double def, double min, double max, double step, String unit) {
            super(name, description);
            this.def = def;
            this.min = min;
            this.max = max;
            this.step = step;
            this.unit = unit;
            this.value = def;
        }

        public double get() { return value; }
        public int getInt() { return (int) Math.round(value); }

        public void set(double v) {
            v = Math.max(min, Math.min(max, v));
            if (step > 0) v = Math.round((v - min) / step) * step + min;
            value = Math.max(min, Math.min(max, v));
        }

        public String text() {
            if (step >= 1) return (int) Math.round(value) + unit;
            return String.format(Locale.ROOT, "%.2f", value) + unit;
        }

        @Override public void reset() { value = def; }
        @Override public JsonElement save() { return new JsonPrimitive(value); }
        @Override public void load(JsonElement e) {
            if (e != null && e.isJsonPrimitive()) set(e.getAsDouble());
        }
    }

    // ------------------------------------------------------------------ Mode
    public static class Mode extends Setting {
        public final String[] options;
        public int index;
        private final int def;

        public Mode(String name, String description, String[] options, int def) {
            super(name, description);
            this.options = options;
            this.def = def;
            this.index = def;
        }

        public String get() { return options[index]; }
        public int idx() { return index; }

        public void cycle(int dir) {
            index = (index + dir + options.length) % options.length;
        }

        @Override public void reset() { index = def; }
        @Override public JsonElement save() { return new JsonPrimitive(get()); }
        @Override public void load(JsonElement e) {
            if (e == null || !e.isJsonPrimitive()) return;
            String s = e.getAsString();
            for (int i = 0; i < options.length; i++) {
                if (options[i].equals(s)) { index = i; return; }
            }
        }
    }

    // ----------------------------------------------------------------- Color
    public static final class Color extends Mode {
        private static final String[] NAMES = {"White", "Light Gray", "Gray", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple"};
        private static final int[] RGB = {0xFFFFFF, 0xC8CDD4, 0x8A9099, 0xE5534B, 0xE8903C, 0xE6C84A, 0x5CC46B, 0x4FC3D9, 0x5B8DEF, 0xA17BEF};

        public Color(String name, String description, int defIndex) {
            super(name, description, NAMES, defIndex);
        }

        public int rgb() { return RGB[index]; }
        /** Opaque ARGB for drawing in-world overlays. */
        public int argb() { return 0xFF000000 | RGB[index]; }
    }

    // ----------------------------------------------------------------- Multi
    public static final class Multi extends Setting {
        public final String[] options;
        public final boolean[] on;
        private final boolean[] def;

        public Multi(String name, String description, String[] options, boolean[] defaults) {
            super(name, description);
            this.options = options;
            this.def = defaults.clone();
            this.on = defaults.clone();
        }

        public boolean has(String option) {
            for (int i = 0; i < options.length; i++) {
                if (options[i].equals(option)) return on[i];
            }
            return false;
        }

        public boolean any() {
            for (boolean b : on) if (b) return true;
            return false;
        }

        @Override public void reset() { System.arraycopy(def, 0, on, 0, on.length); }

        @Override public JsonElement save() {
            JsonArray a = new JsonArray();
            for (int i = 0; i < options.length; i++) if (on[i]) a.add(options[i]);
            return a;
        }

        @Override public void load(JsonElement e) {
            if (e == null || !e.isJsonArray()) return;
            for (int i = 0; i < on.length; i++) on[i] = false;
            for (JsonElement x : e.getAsJsonArray()) {
                String s = x.getAsString();
                for (int i = 0; i < options.length; i++) if (options[i].equals(s)) on[i] = true;
            }
        }
    }

    // ---------------------------------------------------------------- Action
    /** A button inside a module's settings. Not persisted. */
    public static final class Action extends Setting {
        public final Runnable run;

        public Action(String name, String description, Runnable run) {
            super(name, description);
            this.run = run;
        }

        @Override public void reset() {}
        @Override public JsonElement save() { return null; }
        @Override public void load(JsonElement e) {}
    }
}
