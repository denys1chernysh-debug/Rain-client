package com.rain.client.module.crystal;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Stats;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Measures how long End Crystals live as seen by your client, plus the gap between placements. */
public final class CrystalOptimizer extends Module {
    private final Setting.Bool timingDisplay = add(new Setting.Bool("Timing Display", "Show placement/destruction timing statistics.", true));
    private final Setting.Bool latencyGraph = add(new Setting.Bool("Latency Graph", "Draw a graph of the last crystal lifetimes.", true));
    private final Setting.Bool notifications = add(new Setting.Bool("Notifications", "Chat message with each measured crystal lifetime.", false));

    private final Map<Integer, Long> seen = new HashMap<>();
    private final Stats lifetime = new Stats(30);
    private final Stats placeGap = new Stats(30);
    private long lastPlaceNs;
    private int placed, destroyed, ping = -1;

    public CrystalOptimizer() {
        super("Crystal Optimizer", Category.CRYSTAL_MACE,
                "Tracks crystal placement and destruction events and measures observed delays.",
                "Times are measured when your client sees the entity appear/disappear, so they include network latency and cannot show server-internal timing. Nothing is optimized or changed for you.");
    }

    @Override
    public void onEnable() {
        seen.clear();
        lifetime.clear();
        placeGap.clear();
        placed = destroyed = 0;
        lastPlaceNs = 0;
    }

    @Override
    public void tick(Minecraft mc) {
        long now = System.nanoTime();
        Set<Integer> current = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!Util.id(e).equals("end_crystal")) continue;
            current.add(e.getId());
            if (!seen.containsKey(e.getId())) {
                seen.put(e.getId(), now);
                placed++;
                if (lastPlaceNs != 0) placeGap.add((now - lastPlaceNs) / 1_000_000.0);
                lastPlaceNs = now;
            }
        }
        List<Integer> gone = new ArrayList<>();
        for (Map.Entry<Integer, Long> en : seen.entrySet()) {
            if (!current.contains(en.getKey())) gone.add(en.getKey());
        }
        for (Integer id : gone) {
            double ms = (now - seen.remove(id)) / 1_000_000.0;
            destroyed++;
            lifetime.add(ms);
            if (notifications.get()) Util.chat("Crystal lived " + Util.f1(ms) + " ms");
        }
        try {
            PlayerInfo info = mc.getConnection() == null ? null : mc.getConnection().getPlayerInfo(mc.player.getUUID());
            ping = info == null ? -1 : info.getLatency();
        } catch (Throwable t) {
            ping = -1;
        }
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (!latencyGraph.get()) return;
        int gx = o.w - 130, gy = o.h - 140, gw = 120, gh = 40;
        o.rect(gx - 2, gy - 12, gx + gw + 2, gy + gh + 4, 0x90101216);
        o.text("Crystal lifetime (ms)", gx, gy - 10, 0xFFB4BAC2);
        List<Double> r = lifetime.recent();
        double scale = Math.max(200, lifetime.max);
        int n = Math.min(r.size(), 30);
        for (int i = 0; i < n; i++) {
            double v = r.get(r.size() - n + i);
            int bh = (int) Math.min(gh, v / scale * gh);
            int x = gx + i * 4;
            o.rect(x, gy + gh - bh, x + 3, gy + gh, 0xFFC8CDD4);
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        if (!timingDisplay.get()) return l;
        l.add("Placed: " + placed + "  Destroyed: " + destroyed);
        if (lifetime.count > 0) {
            l.add("Lifetime avg: " + Util.f1(lifetime.avg()) + " ms");
            l.add("Min/Max: " + (int) lifetime.min + " / " + (int) lifetime.max + " ms");
        }
        if (placeGap.count > 0) l.add("Place interval avg: " + Util.f1(placeGap.avg()) + " ms");
        l.add("Ping: " + (ping < 0 ? "n/a" : ping + " ms"));
        return l;
    }
}
