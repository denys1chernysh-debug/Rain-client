package com.rain.client.module.combat;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Stats;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Knockback analysis. It reads your velocity; it does NOT reduce or cancel knockback. */
public final class Velocity extends Module {
    private final Setting.Bool horizontalDisplay = add(new Setting.Bool("Horizontal Display", "Show horizontal speed (blocks/tick) live.", true));
    private final Setting.Bool verticalDisplay = add(new Setting.Bool("Vertical Display", "Show vertical speed (blocks/tick) live.", true));
    private final Setting.Bool graph = add(new Setting.Bool("Graph", "Draw a graph of horizontal speed over the last 3 seconds.", true));
    private final Setting.Bool statistics = add(new Setting.Bool("Statistics", "Show hit count and knockback averages.", true));

    private static final int GRAPH_TICKS = 60;
    private final double[] hist = new double[GRAPH_TICKS];
    private final Stats kbH = new Stats(50);
    private final Stats kbV = new Stats(50);
    private Vec3 prev = Vec3.ZERO;
    private float lastHealth = -1;
    private int sampling;
    private double peakH, peakV;
    private double curH, curV;
    private int hits;
    private String last = "";

    public Velocity() {
        super("Velocity", Category.COMBAT,
                "Knockback analysis: live speed, incoming knockback per hit and a speed graph.",
                "Analysis only: it does not change the knockback you take (that is decided by the server). Knockback is detected when you lose health or your velocity jumps sharply.");
    }

    @Override
    public void onEnable() {
        java.util.Arrays.fill(hist, 0);
        kbH.clear();
        kbV.clear();
        hits = 0;
        lastHealth = -1;
        sampling = 0;
        last = "";
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        Vec3 v = p.getDeltaMovement();
        curH = Math.sqrt(v.x * v.x + v.z * v.z);
        curV = v.y;
        System.arraycopy(hist, 1, hist, 0, GRAPH_TICKS - 1);
        hist[GRAPH_TICKS - 1] = curH;

        float hp = p.getHealth();
        double jumpH = Math.sqrt((v.x - prev.x) * (v.x - prev.x) + (v.z - prev.z) * (v.z - prev.z));
        boolean damaged = lastHealth >= 0 && hp < lastHealth - 0.01f;
        boolean impulse = jumpH > 0.30;
        if ((damaged || impulse) && sampling == 0) {
            sampling = 3;
            peakH = 0;
            peakV = 0;
        }
        if (sampling > 0) {
            peakH = Math.max(peakH, curH);
            peakV = Math.max(peakV, Math.abs(curV));
            sampling--;
            if (sampling == 0) {
                hits++;
                kbH.add(peakH);
                kbV.add(peakV);
                last = "Last KB: H " + Util.f2(peakH) + "  V " + Util.f2(peakV);
            }
        }
        lastHealth = hp;
        prev = v;
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (!graph.get()) return;
        int gx = o.w - 130, gy = o.h - 70, gw = 120, gh = 40;
        o.rect(gx - 2, gy - 12, gx + gw + 2, gy + gh + 4, 0x90101216);
        o.text("Horizontal speed", gx, gy - 10, 0xFFB4BAC2);
        double scale = 0.8;
        for (int i = 0; i < GRAPH_TICKS; i++) {
            int bh = (int) Math.min(gh, hist[i] / scale * gh);
            int x = gx + i * 2;
            o.rect(x, gy + gh - bh, x + 2, gy + gh, 0xFFC8CDD4);
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        if (horizontalDisplay.get()) l.add("Horizontal: " + Util.f2(curH) + " b/t");
        if (verticalDisplay.get()) l.add("Vertical: " + Util.f2(curV) + " b/t");
        if (statistics.get()) {
            l.add("Hits taken: " + hits);
            if (kbH.count > 0) l.add("Avg KB: H " + Util.f2(kbH.avg()) + "  V " + Util.f2(kbV.avg()));
            if (!last.isEmpty()) l.add(last);
        }
        return l;
    }
}
