package com.rain.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class Util {
    private static final Map<Block, String> BLOCK_IDS = new HashMap<>();

    private Util() {}

    /** Registry path of an entity type, e.g. "end_crystal". Avoids depending on specific entity classes. */
    public static String id(Entity e) {
        return BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
    }

    public static String id(Block b) {
        return BLOCK_IDS.computeIfAbsent(b, k -> BuiltInRegistries.BLOCK.getKey(k).getPath());
    }

    public static String id(ItemStack s) {
        return s.isEmpty() ? "" : BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
    }

    /**
     * Modules that move the camera are limited to worlds that run on this machine
     * (singleplayer, including worlds opened to LAN). They never act on remote servers.
     */
    public static boolean practiceWorld(Minecraft mc) {
        return mc.hasSingleplayerServer();
    }

    public static void chat(String msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.gui != null) mc.gui.getChat().addMessage(Component.literal("[Rain] " + msg));
    }

    public static String f1(double v) {
        return String.format(Locale.ROOT, "%.1f", v);
    }

    public static String f2(double v) {
        return String.format(Locale.ROOT, "%.2f", v);
    }

    /** "diamond_ore" -> "Diamond Ore" */
    public static String pretty(String path) {
        StringBuilder sb = new StringBuilder();
        for (String part : path.split("_")) {
            if (part.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }

    /** Enchantments on a stack as "Breach 4" style strings. Empty if unreadable. */
    public static List<String> enchants(ItemStack s) {
        List<String> out = new ArrayList<>();
        try {
            for (var e : s.getEnchantments().entrySet()) {
                String n = e.getKey().getRegisteredName();
                int colon = n.indexOf(':');
                if (colon >= 0) n = n.substring(colon + 1);
                out.add(pretty(n) + " " + e.getIntValue());
            }
        } catch (Throwable ignored) {
            // enchantment API differences must never break a module
        }
        return out;
    }

    public static boolean hasEnchant(ItemStack s, String path) {
        for (String e : enchants(s)) if (e.toLowerCase(Locale.ROOT).startsWith(path.toLowerCase(Locale.ROOT))) return true;
        return false;
    }
}
