package com.rain.client.module.base;

import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Counts entities in loaded areas by category and reports population changes over time. */
public final class ActivityTrackers extends Module {
    private static final String[] CATS = {"Villagers", "Farm Animals", "Hostile Mobs", "Players", "Items", "Other"};

    private final Setting.Multi categories = add(new Setting.Multi("Entity Categories", "Which groups are counted.", CATS, new boolean[]{true, true, false, true, false, false}));
    private final Setting.Num radius = add(new Setting.Num("Detection Radius", "Only entities within this distance are counted.", 64, 8, 128, 4, " m"));
    private final Setting.Num updateInterval = add(new Setting.Num("Update Interval", "Seconds between counts.", 2, 1, 30, 1, " s"));
    private final Setting.Num threshold = add(new Setting.Num("Notify Change", "Notify when a count changes by at least this much.", 3, 1, 20, 1, ""));
    private final Setting.Bool notifications = add(new Setting.Bool("Notifications", "Chat message on large population changes.", true));
    private final Setting.Bool statistics = add(new Setting.Bool("Statistics Display", "Show counts, changes and peaks in the HUD panel.", true));

    private final Map<String, Integer> counts = new HashMap<>();
    private final Map<String, Integer> prev = new HashMap<>();
    private final Map<String, Integer> peak = new HashMap<>();
    private final Set<String> playersSeen = new HashSet<>();
    private boolean baseline;
    private int updates;

    public ActivityTrackers() {
        super("Activity Trackers", Category.BASE_HUNTING,
                "Counts villagers, farm animals, mobs, players and items in range and tracks population changes.",
                "Counts only entities your client currently has loaded (render distance limited). Players are seen only while they are within that range.");
    }

    @Override
    public void onEnable() {
        counts.clear();
        prev.clear();
        peak.clear();
        playersSeen.clear();
        baseline = false;
        updates = 0;
    }

    private static String classify(Entity e) {
        String id = Util.id(e);
        if (e instanceof Player) return "Players";
        if (id.equals("villager") || id.equals("wandering_trader")) return "Villagers";
        if (id.equals("cow") || id.equals("sheep") || id.equals("pig") || id.equals("chicken") || id.equals("goat") || id.equals("horse") || id.equals("donkey") || id.equals("mooshroom") || id.equals("rabbit")) return "Farm Animals";
        if (id.equals("item")) return "Items";
        if (e.getType().getCategory() == MobCategory.MONSTER) return "Hostile Mobs";
        return "Other";
    }

    @Override
    public void tick(Minecraft mc) {
        if (mc.player.tickCount % Math.max(1, updateInterval.getInt() * 20) != 0) return;
        Map<String, Integer> now = new HashMap<>();
        for (String c : CATS) now.put(c, 0);
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e == mc.player || mc.player.distanceTo(e) > radius.get()) continue;
            String cat = classify(e);
            if (!categories.has(cat)) continue;
            now.merge(cat, 1, Integer::sum);
            if (e instanceof Player p) playersSeen.add(p.getName().getString());
        }
        updates++;
        for (String c : CATS) {
            if (!categories.has(c)) continue;
            int n = now.get(c);
            int before = prev.getOrDefault(c, n);
            peak.merge(c, n, Math::max);
            if (baseline && notifications.get() && Math.abs(n - before) >= threshold.getInt()) {
                Util.chat(c + (n > before ? " up " : " down ") + before + " -> " + n);
            }
            prev.put(c, n);
        }
        counts.clear();
        counts.putAll(now);
        baseline = true;
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        if (!statistics.get()) return l;
        if (!baseline) {
            l.add("Collecting first sample...");
            return l;
        }
        for (String c : CATS) {
            if (!categories.has(c)) continue;
            l.add(c + ": " + counts.getOrDefault(c, 0) + "  (peak " + peak.getOrDefault(c, 0) + ")");
        }
        if (categories.has("Players") && !playersSeen.isEmpty()) l.add("Players seen: " + playersSeen.size());
        l.add("Samples: " + updates);
        return l;
    }
}
