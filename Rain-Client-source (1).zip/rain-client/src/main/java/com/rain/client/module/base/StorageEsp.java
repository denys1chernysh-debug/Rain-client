package com.rain.client.module.base;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/** Outlines loaded storage block entities. Shows only what the server has actually sent. */
public final class StorageEsp extends Module {
    private static final String[] TYPES = {"Chests", "Shulker Boxes", "Barrels", "Hoppers", "Spawners"};

    private final Setting.Multi types = add(new Setting.Multi("Storage Types", "Which block types are outlined.", TYPES, new boolean[]{true, true, true, true, true}));
    private final Setting.Color color = add(new Setting.Color("Outline Color", "Color of outlines and labels.", 5));
    private final Setting.Num range = add(new Setting.Num("Range", "Maximum distance in blocks.", 64, 8, 128, 4, " m"));
    private final Setting.Bool labels = add(new Setting.Bool("Labels", "Show the block name above each outline.", true));
    private final Setting.Bool distance = add(new Setting.Bool("Distance Display", "Append distance to labels.", true));

    private record Found(BlockPos pos, String name, String type, double dist) {}

    private final List<Found> found = new ArrayList<>();
    private int totalLoaded;

    public StorageEsp() {
        super("Storage ESP", Category.BASE_HUNTING,
                "Outlines chests, shulker boxes, barrels, hoppers and spawners in loaded chunks.",
                "Shows only block entities your client has been sent. It cannot reveal anything the server hides or has not sent (unloaded chunks, anti-Xray). Outlines are screen-space, first person only.");
    }

    private static String classify(String id) {
        if (id.equals("chest") || id.equals("trapped_chest") || id.equals("ender_chest")) return "Chests";
        if (id.endsWith("shulker_box")) return "Shulker Boxes";
        if (id.equals("barrel")) return "Barrels";
        if (id.equals("hopper")) return "Hoppers";
        if (id.equals("spawner")) return "Spawners";
        return null;
    }

    @Override
    public void onEnable() {
        found.clear();
    }

    @Override
    public void tick(Minecraft mc) {
        if (mc.player.tickCount % 10 != 0) return;
        ClientLevel level = mc.level;
        Vec3 pos = mc.player.position();
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        int r = (int) Math.ceil(range.get() / 16.0) + 1;
        List<Found> out = new ArrayList<>();
        int count = 0;
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (!level.getChunkSource().hasChunk(pcx + dx, pcz + dz)) continue;
                LevelChunk ch = level.getChunk(pcx + dx, pcz + dz);
                for (Map.Entry<BlockPos, BlockEntity> en : ch.getBlockEntities().entrySet()) {
                    String id = Util.id(en.getValue().getBlockState().getBlock());
                    String type = classify(id);
                    if (type == null) continue;
                    count++;
                    if (!types.has(type)) continue;
                    double d = pos.distanceTo(Vec3.atCenterOf(en.getKey()));
                    if (d > range.get()) continue;
                    out.add(new Found(en.getKey(), Util.pretty(id), type, d));
                }
            }
        }
        out.sort(Comparator.comparingDouble(Found::dist));
        if (out.size() > 200) out.subList(200, out.size()).clear();
        found.clear();
        found.addAll(out);
        totalLoaded = count;
    }

    @Override
    public void renderOverlay(Overlay o) {
        int argb = color.argb();
        for (Found f : found) {
            AABB b = new AABB(f.pos());
            if (!o.box(b, argb, 1)) continue;
            if (labels.get()) {
                double[] p = o.project(b.getCenter().add(0, 0.7, 0));
                if (p != null) {
                    String s = f.name() + (distance.get() ? " " + (int) f.dist() + "m" : "");
                    o.centered(s, (int) p[0], (int) p[1] - 4, argb);
                }
            }
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("In range: " + found.size() + "   Loaded total: " + totalLoaded);
        for (String t : TYPES) {
            if (!types.has(t)) continue;
            int n = 0;
            for (Found f : found) if (f.type().equals(t)) n++;
            if (n > 0) l.add(t + ": " + n);
        }
        return l;
    }
}
