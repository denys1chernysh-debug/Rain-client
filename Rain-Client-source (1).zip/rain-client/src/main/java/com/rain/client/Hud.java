package com.rain.client;

import com.rain.client.gui.RainScreen;
import com.rain.client.module.Module;
import com.rain.client.module.ModuleManager;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.List;

/** Draws module overlays and the stacked info panels (top-left) every frame. */
public final class Hud {
    private Hud() {}

    public static void render(GuiGraphicsExtractor g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        if (mc.screen instanceof RainScreen) return;

        float pt = dt.getGameTimeDeltaPartialTick(false);
        Overlay o = new Overlay(g, mc, pt);

        for (Module m : ModuleManager.ALL) {
            if (m.enabled) ModuleManager.guard(m, "overlay", () -> m.renderOverlay(o));
        }

        int y = 6;
        for (Module m : ModuleManager.ALL) {
            if (!m.enabled) continue;
            List<String>[] holder = new List[1];
            ModuleManager.guard(m, "hud", () -> holder[0] = m.hudLines());
            List<String> lines = holder[0];
            if (lines == null || lines.isEmpty()) continue;

            int width = o.width(m.name);
            for (String s : lines) width = Math.max(width, o.width(s));
            int height = 12 + lines.size() * 10 + 4;
            if (y + height > o.h - 4) break;

            o.rect(6, y, 6 + width + 12, y + height, 0x90101216);
            o.rect(6, y, 8, y + height, 0xFFC8CDD4);
            o.text(m.name, 12, y + 3, 0xFFF0F2F5);
            int ly = y + 14;
            for (String s : lines) {
                o.text(s, 12, ly, 0xFFB4BAC2);
                ly += 10;
            }
            y += height + 4;
        }
    }
}
