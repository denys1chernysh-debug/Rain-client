package com.rain.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.rain.client.module.Module;
import com.rain.client.module.ModuleManager;
import com.rain.client.module.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;

/** JSON persistence for module state, settings, keybinds and the three transparency values. */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static boolean dirty;
    private static int ticks;

    private Config() {}

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("rain-client.json");
    }

    public static void markDirty() {
        dirty = true;
    }

    /** Debounced autosave; called every client tick. */
    public static void tick() {
        if (!dirty) return;
        if (++ticks >= 40) save();
    }

    public static synchronized void save() {
        try {
            JsonObject root = new JsonObject();

            JsonObject ui = new JsonObject();
            ui.addProperty("interfaceOpacity", UiSettings.interfaceOpacity);
            ui.addProperty("buttonTransparency", UiSettings.buttonTransparency);
            ui.addProperty("backgroundTransparency", UiSettings.backgroundTransparency);
            ui.addProperty("category", UiSettings.category);
            root.add("ui", ui);

            JsonObject mods = new JsonObject();
            for (Module m : ModuleManager.ALL) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.enabled);
                o.addProperty("key", m.keybind);
                o.addProperty("expanded", m.expanded);
                JsonObject s = new JsonObject();
                for (Setting st : m.settings) {
                    JsonElement e = st.save();
                    if (e != null) s.add(st.name, e);
                }
                o.add("settings", s);
                mods.add(m.name, o);
            }
            root.add("modules", mods);

            Files.createDirectories(path().getParent());
            Files.writeString(path(), GSON.toJson(root));
            dirty = false;
            ticks = 0;
        } catch (Exception e) {
            RainClient.LOG.error("Could not save Rain config", e);
        }
    }

    public static synchronized void load() {
        Path p = path();
        if (!Files.exists(p)) return;
        try (Reader r = Files.newBufferedReader(p)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();

            if (root.has("ui")) {
                JsonObject ui = root.getAsJsonObject("ui");
                if (ui.has("interfaceOpacity")) UiSettings.interfaceOpacity = UiSettings.clamp(ui.get("interfaceOpacity").getAsInt(), 10, 100);
                if (ui.has("buttonTransparency")) UiSettings.buttonTransparency = UiSettings.clamp(ui.get("buttonTransparency").getAsInt(), 0, 100);
                if (ui.has("backgroundTransparency")) UiSettings.backgroundTransparency = UiSettings.clamp(ui.get("backgroundTransparency").getAsInt(), 0, 100);
                if (ui.has("category")) UiSettings.category = UiSettings.clamp(ui.get("category").getAsInt(), 0, 3);
            }

            if (root.has("modules")) {
                JsonObject mods = root.getAsJsonObject("modules");
                for (Module m : ModuleManager.ALL) {
                    if (!mods.has(m.name)) continue;
                    try {
                        JsonObject o = mods.getAsJsonObject(m.name);
                        if (o.has("key")) m.keybind = o.get("key").getAsInt();
                        if (o.has("expanded")) m.expanded = o.get("expanded").getAsBoolean();
                        if (o.has("settings")) {
                            JsonObject s = o.getAsJsonObject("settings");
                            for (Setting st : m.settings) {
                                if (!s.has(st.name)) continue;
                                try {
                                    st.load(s.get(st.name));
                                } catch (Exception ex) {
                                    RainClient.LOG.warn("Bad value for {}.{}, keeping default", m.name, st.name);
                                }
                            }
                        }
                        if (o.has("enabled") && o.get("enabled").getAsBoolean()) m.setEnabled(true);
                    } catch (Exception ex) {
                        RainClient.LOG.warn("Could not load config for module {}", m.name, ex);
                    }
                }
            }
        } catch (Exception e) {
            RainClient.LOG.error("Could not read Rain config, using defaults", e);
        }
    }
}
