package com.rain.client.module.combat;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Visualization only. It never sends rotation packets or modifies what the server sees.
 */
public final class SilentAim extends Module {
    private final Setting.Num range = add(new Setting.Num("Target Range", "Maximum distance for target selection.", 6, 1, 16, 0.5, " m"));
    private final Setting.Num fov = add(new Setting.Num("FOV", "Full width of the selection cone around your crosshair.", 120, 10, 360, 5, "°"));
    private final Setting.Mode priority = add(new Setting.Mode("Target Priority", "How the target is chosen among eligible ones.", Targets.PRIORITIES, 0));
    private final Setting.Mode indicator = add(new Setting.Mode("Target Indicator", "How the selected target is marked on screen.", new String[]{"Box", "Marker", "Off"}, 0));
    private final Setting.Color color = add(new Setting.Color("Indicator Color", "Color of the target indicator.", 1));
    private final Setting.Bool players = add(new Setting.Bool("Include Players", "Also consider other players.", true));

    private Entity target;
    private float dyaw, dpitch;
    private double dist;

    public SilentAim() {
        super("Silent Aim", Category.COMBAT,
                "Shows which target would be selected and how far your camera is from it. Visualization only.",
                "Hit registration is decided by the server from the rotation and position packets the client sends. "
                        + "This module only displays information; client-side code cannot independently change server hit registration, and this module changes nothing you send.");
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        target = Targets.best(mc, range.get(), fov.get(), priority.idx(), players.get(), false);
        if (target == null) return;
        Vec3 eye = p.getEyePosition();
        Vec3 c = target.getBoundingBox().getCenter();
        dyaw = Mth.wrapDegrees(Targets.yawTo(eye, c) - p.getYRot());
        dpitch = Targets.pitchTo(eye, c) - p.getXRot();
        dist = p.distanceTo(target);
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (target == null || indicator.get().equals("Off")) return;
        AABB b = target.getBoundingBox();
        if (indicator.get().equals("Box")) {
            o.box(b, color.argb(), 1);
        } else {
            o.marker(b.getCenter(), "target", color.argb());
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        if (target == null) {
            l.add("No target in range/FOV");
        } else {
            AABB b = target.getBoundingBox();
            l.add("Target: " + Targets.describe(target));
            l.add("Distance: " + Util.f1(dist) + " m");
            l.add("Hitbox: " + Util.f2(b.getXsize()) + " x " + Util.f2(b.getYsize()) + " x " + Util.f2(b.getZsize()));
            l.add("Camera offset: yaw " + Util.f1(dyaw) + "°, pitch " + Util.f1(dpitch) + "°");
        }
        l.add("Server decides hit registration.");
        return l;
    }
}
