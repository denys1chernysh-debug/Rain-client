package com.rain.client.module.base;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Outlines chosen block types found in the chunk data the client has received. */
public final class BlockEsp extends Module {
    private static final String[] CATS = {"Diamond Ore", "Ancient Debris", "Emerald Ore", "Gold Ore", "Iron Ore", "Lapis Ore",
            "Redstone Ore", "Coal Ore", "Copper Ore", "Obsidian", "Spawner", "Budding Amethyst"};
    private static final Map<Block, Integer> CAT_CACHE = new HashMap<>();

    private final Setting.Multi selection = add(new Setting.Multi("Block Selection", "Which block categories are highlighted.", CATS,
            new boolean[]{true, true, false, false, false, false, false, false, false, false, false, false}));
    private final Setting.Color color = add(new Setting.Color("Outline Color", "Color of outlines and labels.", 7));
    private final Setting.Num range = add(new Setting.Num("Range", "Maximum distance in blocks.", 48, 8, 96, 4, " m"));
    private final Setting.Num thickness = add(new Setting.Num("Thickness", "Outline width in pixels.", 1, 1, 4, 1, " px"));
    private final Setting.Bool labels = add(new Setting.Bool("Labels", "Show block names and distances.", true));

    private record Hit(int x, int y, int z, int cat) {}

    private final Map<Long, List<Hit>> byChunk = new HashMap<>();
    private final Map<Long, Long> scannedAt = new HashMap<>();
    private final List<Hit> visible = new ArrayList<>();
    private Vec3 lastPos = Vec3.ZERO;

    public BlockEsp() {
        super("Block ESP", Category.BASE_HUNTING,
                "Outlines selected block types (ores, obsidian, spawners...) in loaded chunks.",
                "Only blocks in chunk data your client received are found. Servers with anti-Xray send altered data, so hidden ores will not appear. Outlines are screen-space, first person only.");
    }

    private static int catOf(Block b) {
        return CAT_CACHE.computeIfAbsent(b, k -> {
            String id = Util.id(k);
            if (id.contains("diamond_ore")) return 0;
            if (id.equals("ancient_debris")) return 1;
            if (id.contains("emerald_ore")) return 2;
            if (id.contains("gold_ore")) return 3;
            if (id.contains("iron_ore")) return 4;
            if (id.contains("lapis_ore")) return 5;
            if (id.contains("redstone_ore")) return 6;
            if (id.contains("coal_ore")) return 7;
            if (id.contains("copper_ore")) return 8;
            if (id.equals("obsidian")) return 9;
            if (id.equals("spawner")) return 10;
            if (id.equals("budding_amethyst")) return 11;
            return -1;
        });
    }

    @Override
    public void onEnable() {
        byChunk.clear();
        scannedAt.clear();
        visible.clear();
    }

    @Override
    public void onDisable() {
        byChunk.clear();
        scannedAt.clear();
        visible.clear();
    }

    @Override
    public void tick(Minecraft mc) {
        ClientLevel level = mc.level;
        long now = level.getGameTime();
        int pcx = mc.player.blockPosition().getX() >> 4, pcz = mc.player.blockPosition().getZ() >> 4;
        int r = (int) Math.ceil(range.get() / 16.0);

        // scan at most one chunk every 4 ticks, nearest stale chunk first
        if (mc.player.tickCount % 4 == 0 && selection.any()) {
            int bestD = Integer.MAX_VALUE, bx = 0, bz = 0;
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    int d = dx * dx + dz * dz;
                    if (d >= bestD) continue;
                    if (!level.getChunkSource().hasChunk(pcx + dx, pcz + dz)) continue;
                    Long at = scannedAt.get(ChunkPos.asLong(pcx + dx, pcz + dz));
                    if (at != null && now - at < 200) continue;
                    bestD = d;
                    bx = pcx + dx;
                    bz = pcz + dz;
                }
            }
            if (bestD != Integer.MAX_VALUE) {
                long key = ChunkPos.asLong(bx, bz);
                scannedAt.put(key, now);
                byChunk.put(key, scan(level, level.getChunk(bx, bz), bx, bz));
            }
        }

        if (mc.player.tickCount % 10 == 0) {
            lastPos = mc.player.position();
            List<Hit> all = new ArrayList<>();
            for (List<Hit> list : byChunk.values()) {
                for (Hit h : list) {
                    if (!selection.on[h.cat()]) continue;
                    if (lastPos.distanceTo(new Vec3(h.x() + 0.5, h.y() + 0.5, h.z() + 0.5)) <= range.get()) all.add(h);
                }
            }
            all.sort(Comparator.comparingDouble(h -> lastPos.distanceToSqr(h.x() + 0.5, h.y() + 0.5, h.z() + 0.5)));
            if (all.size() > 150) all.subList(150, all.size()).clear();
            visible.clear();
            visible.addAll(all);
        }
    }

    private List<Hit> scan(ClientLevel level, LevelChunk ch, int cx, int cz) {
        List<Hit> out = new ArrayList<>();
        int minSec = ch.getMinSectionY();
        for (int si = 0; si < ch.getSectionsCount(); si++) {
            LevelChunkSection sec = ch.getSection(si);
            if (sec.hasOnlyAir()) continue;
            if (!sec.maybeHas(s -> catOf(s.getBlock()) >= 0 && selection.on[catOf(s.getBlock())])) continue;
            int baseY = (minSec + si) << 4;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        int c = catOf(sec.getBlockState(x, y, z).getBlock());
                        if (c >= 0 && selection.on[c]) {
                            out.add(new Hit((cx << 4) + x, baseY + y, (cz << 4) + z, c));
                            if (out.size() >= 400) return out;
                        }
                    }
                }
            }
        }
        return out;
    }

    @Override
    public void renderOverlay(Overlay o) {
        int argb = color.argb();
        Vec3 me = o.mc.player.position();
        for (Hit h : visible) {
            AABB b = new AABB(h.x(), h.y(), h.z(), h.x() + 1, h.y() + 1, h.z() + 1);
            if (!o.box(b, argb, thickness.getInt())) continue;
            if (labels.get()) {
                double[] p = o.project(b.getCenter().add(0, 0.7, 0));
                if (p != null) o.centered(CATS[h.cat()] + " " + (int) me.distanceTo(b.getCenter()) + "m", (int) p[0], (int) p[1] - 4, argb);
            }
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("Highlighted: " + visible.size());
        l.add("Chunks analysed: " + byChunk.size());
        if (!selection.any()) l.add("No block category selected");
        return l;
    }
}
