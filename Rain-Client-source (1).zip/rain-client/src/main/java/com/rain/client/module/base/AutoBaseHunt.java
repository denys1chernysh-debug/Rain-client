package com.rain.client.module.base;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Exploration helper: tracks which chunks you have loaded, marks Base Finder candidates and shows
 * navigation guidance to a destination. It never moves you or digs.
 */
public final class AutoBaseHunt extends Module {
    private final Setting.Num searchRadius = add(new Setting.Num("Search Radius", "Candidates and progress are limited to this distance from where you started.", 256, 64, 512, 16, " m"));
    private final Setting.Bool destinationMarkers = add(new Setting.Bool("Destination Markers", "Draw markers on candidates and the manual destination.", true));
    private final Setting.Bool navigationDisplay = add(new Setting.Bool("Navigation Display", "Show distance and turn direction to the current destination.", true));
    private final Setting.Bool notifications = add(new Setting.Bool("Notifications", "Chat message when a new candidate appears in range.", true));
    @SuppressWarnings("unused")
    private final Setting.Action setDest = add(new Setting.Action("Set Destination (Looked-at Block)", "Use the block under your crosshair (or your position) as destination.", this::setDestination));
    @SuppressWarnings("unused")
    private final Setting.Action clearDest = add(new Setting.Action("Clear Destination", "Go back to following the nearest Base Finder candidate.", () -> manual = null));
    @SuppressWarnings("unused")
    private final Setting.Action resetProgress = add(new Setting.Action("Reset Exploration Progress", "Forget explored chunks and restart from your current position.", this::resetProgressNow));

    private final Set<Long> explored = new HashSet<>();
    private BlockPos origin;
    private BlockPos manual;
    private BlockPos navTarget;
    private String navLabel = "";
    private double navDist;
    private float navTurn;
    private int candidateCount, knownCandidates;
    private double progress;

    public AutoBaseHunt() {
        super("Auto Base Hunt", Category.BASE_HUNTING,
                "Tracks explored chunks, marks Base Finder candidates and guides you to a destination.",
                "Guidance only: it never moves you, digs or enters protected areas. Candidates come from Base Finder (enable it for fresh results); progress covers chunks your client has loaded.");
    }

    private void setDestination() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
            manual = hit.getBlockPos();
        } else {
            manual = mc.player.blockPosition();
        }
        Util.chat("Destination set: " + manual.getX() + ", " + manual.getY() + ", " + manual.getZ());
    }

    private void resetProgressNow() {
        explored.clear();
        Minecraft mc = Minecraft.getInstance();
        origin = mc.player == null ? null : mc.player.blockPosition();
        knownCandidates = 0;
    }

    @Override
    public void onEnable() {
        explored.clear();
        Minecraft mc = Minecraft.getInstance();
        origin = mc.player == null ? null : mc.player.blockPosition();
        knownCandidates = 0;
    }

    @Override
    public void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (origin == null) origin = p.blockPosition();

        if (p.tickCount % 20 == 0) {
            int pcx = p.blockPosition().getX() >> 4, pcz = p.blockPosition().getZ() >> 4;
            int r = Math.min(24, (int) (searchRadius.get() / 16));
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    if (mc.level.getChunkSource().hasChunk(pcx + dx, pcz + dz)) explored.add(ChunkPos.asLong(pcx + dx, pcz + dz));
                }
            }
            int ocx = origin.getX() >> 4, ocz = origin.getZ() >> 4;
            int rr = (int) (searchRadius.get() / 16);
            int inDisc = 0, total = 0;
            for (int dx = -rr; dx <= rr; dx++) {
                for (int dz = -rr; dz <= rr; dz++) {
                    if (dx * dx + dz * dz > rr * rr) continue;
                    total++;
                    if (explored.contains(ChunkPos.asLong(ocx + dx, ocz + dz))) inDisc++;
                }
            }
            progress = total == 0 ? 0 : (double) inDisc / total;
        }

        // choose the navigation target
        List<BaseFinder.Detection> near = new ArrayList<>();
        for (BaseFinder.Detection d : BaseFinder.sorted()) {
            if (d.percent < BaseFinder.threshold()) continue;
            if (Math.sqrt(d.center.distSqr(origin)) > searchRadius.get() * 1.5) continue;
            near.add(d);
        }
        candidateCount = near.size();
        if (notifications.get() && candidateCount > knownCandidates) {
            Util.chat("New base candidate in range (" + candidateCount + " total)");
        }
        knownCandidates = Math.max(knownCandidates, candidateCount);

        navTarget = null;
        if (manual != null) {
            navTarget = manual;
            navLabel = "Destination";
        } else {
            double best = Double.MAX_VALUE;
            for (BaseFinder.Detection d : near) {
                double dist = p.position().distanceTo(Vec3.atCenterOf(d.center));
                if (dist < best) {
                    best = dist;
                    navTarget = d.center;
                    navLabel = d.percent + "% candidate";
                }
            }
        }
        if (navTarget != null) {
            Vec3 t = Vec3.atCenterOf(navTarget);
            navDist = p.position().distanceTo(t);
            float yawTo = (float) (Math.toDegrees(Math.atan2(t.z - p.getZ(), t.x - p.getX())) - 90.0);
            navTurn = Mth.wrapDegrees(yawTo - p.getYRot());
        }
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (destinationMarkers.get()) {
            for (BaseFinder.Detection d : BaseFinder.sorted()) {
                if (d.percent < BaseFinder.threshold()) continue;
                o.marker(Vec3.atCenterOf(d.center), "candidate " + d.percent + "%", 0xFFE8903C);
            }
            if (manual != null) o.marker(Vec3.atCenterOf(manual), "Destination", 0xFF4FC3D9);
        }
        if (navigationDisplay.get() && navTarget != null) {
            String dir = Math.abs(navTurn) < 10 ? "ahead" : navTurn > 0 ? "turn right " + (int) Math.abs(navTurn) + "°" : "turn left " + (int) Math.abs(navTurn) + "°";
            o.centered(navLabel + ": " + (int) navDist + " m, " + dir, o.w / 2, 12, 0xFFE8EAED);
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("Explored chunks: " + explored.size());
        l.add("Progress (radius " + searchRadius.getInt() + " m): " + (int) (progress * 100) + "%");
        l.add("Candidates in range: " + candidateCount);
        if (navigationDisplay.get()) {
            if (navTarget == null) l.add("No destination (set one or find candidates)");
            else l.add(navLabel + ": " + (int) navDist + " m");
        }
        return l;
    }
}
