package com.rain.client.module.crystal;

import com.rain.client.Overlay;
import com.rain.client.module.Category;
import com.rain.client.module.Module;
import com.rain.client.module.Setting;
import com.rain.client.util.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Finds and highlights valid crystal placement spots. Display only: it never places crystals. */
public final class AutoCrystal extends Module {
    private final Setting.Num range = add(new Setting.Num("Placement Range", "How far around you spots are searched.", 5, 2, 6, 0.5, " m"));
    private final Setting.Bool indicators = add(new Setting.Bool("Visual Indicators", "Outline valid obsidian/bedrock blocks.", true));
    private final Setting.Color color = add(new Setting.Color("Indicator Color", "Color of the outlines.", 7));
    private final Setting.Bool notifications = add(new Setting.Bool("Placement Notifications", "Chat message when a spot becomes available.", false));
    private final Setting.Bool holdingOnly = add(new Setting.Bool("Only While Holding Crystal", "Only search while an End Crystal is in a hand.", false));

    private final List<BlockPos> spots = new ArrayList<>();
    private long openSince;
    private long lastNotify;
    private int totalSeen;

    public AutoCrystal() {
        super("Auto Crystal", Category.CRYSTAL_MACE,
                "Highlights obsidian and bedrock blocks where an End Crystal could be placed.",
                "Practice assistant: it shows spots (solid obsidian/bedrock with two free blocks above and no entity in the way) but never places crystals or interacts for you.");
    }

    @Override
    public void onEnable() {
        spots.clear();
        openSince = 0;
        totalSeen = 0;
    }

    @Override
    public void tick(Minecraft mc) {
        if (mc.player.tickCount % 5 != 0) return;
        LocalPlayer p = mc.player;
        if (holdingOnly.get() && !Util.id(p.getMainHandItem()).equals("end_crystal") && !Util.id(p.getOffhandItem()).equals("end_crystal")) {
            spots.clear();
            openSince = 0;
            return;
        }
        Level level = mc.level;
        BlockPos base = p.blockPosition();
        Vec3 pos = p.position();
        int r = (int) Math.ceil(range.get());
        List<BlockPos> found = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    BlockPos b = base.offset(dx, dy, dz);
                    if (pos.distanceTo(Vec3.atCenterOf(b)) > range.get()) continue;
                    String id = Util.id(level.getBlockState(b).getBlock());
                    if (!id.equals("obsidian") && !id.equals("bedrock")) continue;
                    if (!level.getBlockState(b.above()).isAir() || !level.getBlockState(b.above(2)).isAir()) continue;
                    AABB space = new AABB(b.above().getX(), b.above().getY(), b.above().getZ(), b.getX() + 1, b.getY() + 3, b.getZ() + 1);
                    if (!level.getEntities((Entity) null, space, e -> true).isEmpty()) continue;
                    found.add(b);
                }
            }
        }
        found.sort(Comparator.comparingDouble(b -> pos.distanceToSqr(Vec3.atCenterOf(b))));
        if (found.size() > 30) found.subList(30, found.size()).clear();

        boolean had = !spots.isEmpty();
        spots.clear();
        spots.addAll(found);
        if (!spots.isEmpty() && !had) {
            openSince = System.currentTimeMillis();
            totalSeen++;
            long now = System.currentTimeMillis();
            if (notifications.get() && now - lastNotify > 2000) {
                lastNotify = now;
                Util.chat("Crystal spot available (" + spots.size() + ")");
            }
        } else if (spots.isEmpty()) {
            openSince = 0;
        }
    }

    @Override
    public void renderOverlay(Overlay o) {
        if (!indicators.get()) return;
        for (BlockPos b : spots) {
            o.box(new AABB(b.getX(), b.getY(), b.getZ(), b.getX() + 1, b.getY() + 1, b.getZ() + 1), color.argb(), 1);
        }
    }

    @Override
    public List<String> hudLines() {
        List<String> l = new ArrayList<>();
        l.add("Valid spots: " + spots.size());
        if (!spots.isEmpty()) {
            l.add("Open for: " + (System.currentTimeMillis() - openSince) + " ms");
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) l.add("Nearest: " + Util.f1(mc.player.position().distanceTo(Vec3.atCenterOf(spots.get(0)))) + " m");
        }
        l.add("Openings seen: " + totalSeen);
        return l;
    }
}
