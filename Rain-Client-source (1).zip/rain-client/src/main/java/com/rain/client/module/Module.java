package com.rain.client.module;

import com.rain.client.Overlay;
import com.rain.client.RainClient;
import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for every Rain module. Each module is its own subclass.
 * Lifecycle calls are wrapped by {@link ModuleManager#guard}, so an exception in one
 * module never crashes the game; after repeated failures the module disables itself.
 */
public abstract class Module {
    public final String name;
    public final String description;
    public final Category category;
    /** Plain-language description of what this module can NOT do (server limits, missing data...). */
    public final String limitation;

    public final List<Setting> settings = new ArrayList<>();
    public boolean enabled;
    /** GLFW key code, or -1 for none. */
    public int keybind = -1;
    public boolean expanded;

    public String lastError = "";
    private int errorCount;

    protected Module(String name, Category category, String description, String limitation) {
        this.name = name;
        this.category = category;
        this.description = description;
        this.limitation = limitation;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        try {
            if (value) {
                lastError = "";
                errorCount = 0;
                onEnable();
            } else {
                onDisable();
            }
        } catch (Throwable t) {
            fail(value ? "enable" : "disable", t);
        }
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void reset() {
        for (Setting s : settings) s.reset();
        keybind = -1;
    }

    /** Called by ModuleManager when a lifecycle method throws. */
    public void fail(String phase, Throwable t) {
        lastError = phase + ": " + t.getClass().getSimpleName() + (t.getMessage() != null ? " - " + t.getMessage() : "");
        errorCount++;
        RainClient.LOG.error("Module '{}' failed during {}", name, phase, t);
        if (errorCount >= 5 && enabled) {
            enabled = false;
            lastError += " (disabled after repeated errors)";
        }
    }

    // ------------------------------------------------------------ lifecycle
    public void onEnable() {}
    public void onDisable() {}

    /** Runs every client tick while enabled and in a world. */
    public void tick(Minecraft mc) {}

    /** Runs every rendered frame while enabled; draw projected markers, boxes and labels here. */
    public void renderOverlay(Overlay o) {}

    /** Lines shown in this module's HUD panel (the module name is the title). Empty = no panel. */
    public List<String> hudLines() {
        return List.of();
    }
}
