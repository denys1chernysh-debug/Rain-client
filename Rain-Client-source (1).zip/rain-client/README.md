# Rain Client 1.0.0 (Fabric, Minecraft 26.2, Java 25)

Build:  ./gradlew build   (or `gradle build`)  ->  build/libs/Rain-Client-1.0.0.jar
Open the GUI in a world with RIGHT SHIFT. Config: config/rain-client.json (autosaved).

STATUS: source only. It was NOT compiled or run (the authoring sandbox had no network, so Loom and the 26.2 jars could not be downloaded).
Expect a few compile errors against 26.2 names; send them back and they get fixed.
Most likely to need adjustment: Screen input signatures (RainScreen), GuiGraphicsExtractor calls (fill/text/enableScissor),
HudElementRegistry (RainClient), Inventory.getSelectedSlot, RespawnAnchor property name.
